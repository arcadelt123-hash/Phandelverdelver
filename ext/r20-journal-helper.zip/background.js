// Roll20 저널 도우미 - 배경 스크립트
const CFG = {
  apiKey: 'AIzaSyCQPLIq529f1g5YwJ3fJvv8CVWd-E5TBak',
  db: 'https://tabletop-journal-57381-default-rtdb.asia-southeast1.firebasedatabase.app'
};
const DEFAULT_SITES = [
  { match: '판델버', room: 'r_Phandelverdelver', url: 'https://arcadelt123-hash.github.io/Phandelverdelver/', exec: 'https://script.google.com/macros/s/AKfycbzamFZWIFpfAbXgZkt7oihFeaVZmyJD8CcNZHWVd1wCia_dueuJrWH5cuZBaf92Jb0O/exec' },
  { match: '평일', room: 'r_TUEdragonheist', url: 'https://arcadelt123-hash.github.io/TUEdragonheist/', exec: 'https://script.google.com/macros/s/AKfycbwJ-98tXwMDDOlBcRfzVARwU3Ub5ixtObVjSIVsdalMPgvidSjh5RhUlW-8I8rtfG7X/exec' },
  { match: '드래곤', room: 'r_Dragonheisthesit', url: 'https://arcadelt123-hash.github.io/Dragonheisthesit/', exec: 'https://script.google.com/macros/s/AKfycbzcRwin9hPrNjvfH23sOm4iYYe4SZJazqp66Ri416tUZF1-4TzNkIWIaOmcyM3DqnWm/exec' }
];
const sameUrl = (a, b) => (a || '').replace(/#.*$/, '').replace(/\/$/, '') === (b || '').replace(/#.*$/, '').replace(/\/$/, '');

// 저장된 목록에 없는 기본 사이트는 뒤에 붙여 줘요 (옵션을 예전에 저장했어도 새 게임이 빠지지 않게). 서버 주소(exec)가 없으면 기본값으로 채워요
async function getSites() {
  const s = await chrome.storage.sync.get('sites'); const L = Array.isArray(s.sites) && s.sites.length ? s.sites.map(x => Object.assign({}, x)) : [];
  DEFAULT_SITES.forEach(d => { const e = L.find(x => sameUrl(x.url, d.url)); if (!e) L.push(Object.assign({}, d)); else if (!e.exec) e.exec = d.exec; });
  return L;
}

// ---- Firebase 로그인: 저널 로그인 표(기기 토큰) → 저널 서버가 만든 출입증 → Firebase ----
// (예전 익명 로그인은 2차 보안 수정 뒤로 막혀서, 저널과 같은 방식으로 들어가요. 방마다 따로)
class NoTk extends Error {}
async function token(site) {
  const k = 'fb_' + site.room, s = (await chrome.storage.local.get(k))[k] || {};
  if (s.idToken && s.exp && Date.now() < s.exp - 60000) return s.idToken;
  let r, j;
  if (s.refresh) {
    r = await fetch('https://securetoken.googleapis.com/v1/token?key=' + CFG.apiKey, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(s.refresh) });
    j = await r.json().catch(() => ({}));
    if (r.ok && j.id_token) { await chrome.storage.local.set({ [k]: { idToken: j.id_token, refresh: j.refresh_token, exp: Date.now() + Number(j.expires_in) * 1000 } }); return j.id_token; }
  }
  const tk = (await chrome.storage.local.get('tk_' + site.room))['tk_' + site.room];
  if (!tk || !site.exec) throw new NoTk('저널 로그인 정보 없음');
  r = await fetch(site.exec + '?action=fbtok&tk=' + encodeURIComponent(tk));
  j = await r.json().catch(() => ({}));
  if (!j || j.status !== 'OK' || !j.token) { if (j && j.status === 'AUTH') { await chrome.storage.local.remove('tk_' + site.room); throw new NoTk('저널 로그인이 만료됨'); } throw new Error('출입증 실패: ' + (j && j.status)); }
  r = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=' + CFG.apiKey, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: j.token, returnSecureToken: true }) });
  j = await r.json().catch(() => ({}));
  if (!r.ok || !j.idToken) throw new Error('Firebase 로그인 실패');
  await chrome.storage.local.set({ [k]: { idToken: j.idToken, refresh: j.refreshToken, exp: Date.now() + Number(j.expiresIn) * 1000 } });
  return j.idToken;
}
async function fbGet(site, path, q) {
  const t = await token(site);
  const r = await fetch(CFG.db + '/' + path + '.json?auth=' + encodeURIComponent(t) + (q ? '&' + q : ''));
  if (r.status === 401) { await chrome.storage.local.remove('fb_' + site.room); }
  if (!r.ok) throw new Error('Firebase ' + r.status);
  return r.json();
}

// ---- GM 패널: 명령을 보낼 Roll20 게임 탭 고르기 (패널이 들어 있는 탭 → 마지막으로 본 게임 탭 → 아무 게임 탭) ----
async function r20Tab(sender) {
  if (sender && sender.tab && /^https:\/\/app\.roll20\.net\/editor/.test(sender.tab.url || '')) return sender.tab.id;
  const ts = await chrome.tabs.query({ url: 'https://app.roll20.net/editor/*' });
  if (!ts.length) return null;
  const { lastR20 } = await chrome.storage.local.get('lastR20');
  return (ts.find(t => t.id === lastR20) || ts.find(t => t.active) || ts[0]).id;
}
chrome.windows.onRemoved.addListener(async id => {
  const { panelWin } = await chrome.storage.local.get('panelWin');
  if (panelWin === id) await chrome.storage.local.set({ panelWin: null, panelMode: 'mini' });   // 창을 닫으면 게임 화면엔 작은 버튼만
});

// ---- 세션 채팅 기록(아카이브) 읽기 ----
async function archiveGrab(editorTabId) {
  let cid = '';
  try { const [r] = await chrome.scripting.executeScript({ target: { tabId: editorTabId }, world: 'MAIN', func: () => String(window.campaign_id || '') }); cid = (r && r.result) || ''; } catch (e) {}
  if (!/^\d+$/.test(cid)) return { error: '캠페인 번호를 못 읽었어요. Roll20 게임 화면을 새로 고친 뒤 다시 시도해 주세요.' };
  const tab = await chrome.tabs.create({ url: 'https://app.roll20.net/campaigns/chatarchive/' + cid + '/?p=1&onePage=true', active: false });
  try {
    await new Promise(res => { const f = (id, info) => { if (id === tab.id && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(f); res(); } }; chrome.tabs.onUpdated.addListener(f); setTimeout(res, 45000); });
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: archiveSlice });
    return (r && r.result) || { error: '채팅 기록을 읽지 못했어요.' };
  } catch (e) { return { error: '채팅 기록을 읽지 못했어요: ' + e.message }; }
  finally { try { await chrome.tabs.remove(tab.id); } catch (e) {} }
}
// 채팅 기록 페이지 안에서 실행: 다 그려질 때까지 기다린 뒤, 마지막 '세션 마무리' 카드까지 /
// 시작은 그 앞의 마지막 '세션 기록 시작 —'(!세션시작) 다음부터, 없으면 앞 세션의 '세션 마무리' 다음부터, 그것도 없으면 처음부터
async function archiveSlice() {
  let last = -1, stable = 0;
  for (let i = 0; i < 120; i++) { const n = document.querySelectorAll('div.message[data-messageid]').length; if (n === last && n > 0) { if (++stable >= 4) break; } else stable = 0; last = n; await new Promise(r => setTimeout(r, 500)); }
  const all = [...document.querySelectorAll('div.message[data-messageid]')];
  if (!all.length) return { error: '채팅 기록이 비어 있어요. (이미 지웠다면 이번 회차는 가져올 수 없어요)' };
  const isEnd = el => /세션 마무리/.test(el.textContent) && [...el.querySelectorAll('div')].some(d => !d.children.length && d.textContent.trim() === '세션 마무리');
  const isStart = el => /세션 기록 시작 —/.test(el.textContent);
  let end = -1; for (let i = all.length - 1; i >= 0; i--) if (isEnd(all[i])) { end = i; break; }
  if (end < 0) end = all.length - 1;
  let start = 0;
  for (let i = end - 1; i >= 0; i--) { if (isStart(all[i])) { start = i + 1; break; } if (isEnd(all[i])) { start = i + 1; break; } }
  const pick = all.slice(start, end + 1);
  const html = pick.map(el => '<div class="message ' + (el.className || '').replace(/^message\s*/, '').replace(/"/g, '') + '" data-messageid="' + (el.getAttribute('data-messageid') || '').replace(/"/g, '') + '">' +
    el.innerHTML.replace(/ style="[^"]*"/g, '').replace(/<span class="tstamp"[^>]*>[\s\S]*?<\/span>/g, '') + '</div>').join('\n');
  const d = new Date(), p = n => String(n).padStart(2, '0');
  return { html, n: pick.length, date: d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) };
}

// ---- 상점 판매 요청 / 상점 입장 확인 ----
async function poll(site) {
  const room = site.room, key = 'seen_' + room, st = await chrome.storage.local.get(key);
  let since = st[key];
  const out = { sells: [], live: [] };
  const chat = await fbGet(site, 'rooms/' + room + '/chat', 'orderBy=%22%24key%22&limitToLast=25');
  const list = Object.keys(chat || {}).map(k => Object.assign({ id: k }, chat[k])).sort((a, b) => (a.ts || 0) - (b.ts || 0));
  if (since == null) { since = Date.now(); await chrome.storage.local.set({ [key]: since }); return out; }  // 처음엔 지금부터
  let max = since;
  list.forEach(m => { if ((m.ts || 0) > since) { max = Math.max(max, m.ts || 0); if (m.ev === 'sell') out.sells.push({ n: m.n || '', t: m.t || '' }); } });
  if (max > since) await chrome.storage.local.set({ [key]: max });
  try { const live = await fbGet(site, 'rooms/' + room + '/shop/live', ''); const now = Date.now(); out.live = Object.keys(live || {}).map(k => live[k]).filter(x => x && now - (x.t || 0) < 60000).map(x => ({ n: x.n, s: x.s, w: x.w, pc: x.pc })); } catch (e) {}
  return out;
}


// ---- PC 시트 → 저널 GitHub (0.7.6) ----
const repoOf = site => { const m = String(site && site.url || '').match(/^https:\/\/([^./]+)\.github\.io\/([^/#?]+)/); return m ? m[1] + '/' + m[2] : null; };
function sxLevel(p) {
  if (p.store) {
    const I = Object.values(((p.store.integrants || {}).integrants) || {}).filter(v => v.type === 'Class Level' && v._enabled !== false);
    const by = {}; let tot = 0;
    I.forEach(v => { if (v.name) by[v.name] = Math.max(by[v.name] || 0, +v.level || 0); tot = Math.max(tot, +v.totalLevel || 0); });
    return Math.max(tot, Object.values(by).reduce((a, x) => a + x, 0));
  }
  const a = p.attrs || {}; return +((a.level || a.base_level || [0])[0]) || 0;
}
// 토큰은 크롬 계정(동기화 저장소)에 둬요 → 같은 구글 계정으로 로그인한 크롬이면 어디서든 (0.7.7)
async function ghTok() {
  const s = (await chrome.storage.sync.get('ghToken')).ghToken; if (s) return s;
  const l = (await chrome.storage.local.get('ghToken')).ghToken;
  if (l) { await chrome.storage.sync.set({ ghToken: l }); await chrome.storage.local.remove('ghToken'); }
  return l || '';
}
const ghUrl = (repo, path) => 'https://api.github.com/repos/' + repo + '/contents/' + path;
async function ghGet(repo, path, tok) {
  const h = { Accept: 'application/vnd.github.raw+json' }; if (tok) h.Authorization = 'Bearer ' + tok;
  const r = await fetch(ghUrl(repo, path), { headers: h, cache: 'no-store' });
  if (r.status === 404) return null;
  if (r.status === 401) throw new Error('GitHub 토큰이 맞지 않거나 만료됐어요. 확장 설정에서 다시 넣어 주세요.');
  if (!r.ok) throw new Error(path + ' 읽기 실패 (' + r.status + ')');
  return r.json();
}
function b64(s) { const u = new TextEncoder().encode(s); let o = ''; for (let i = 0; i < u.length; i += 0x8000) o += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(o); }
async function ghPut(repo, path, obj, message, tok) {
  const H = { Authorization: 'Bearer ' + tok };
  const g = await fetch(ghUrl(repo, path), { headers: Object.assign({ Accept: 'application/vnd.github.object+json' }, H), cache: 'no-store' });
  const sha = g.ok ? (await g.json()).sha : null;
  const r = await fetch(ghUrl(repo, path), { method: 'PUT', headers: Object.assign({ 'Content-Type': 'application/json' }, H), body: JSON.stringify(Object.assign({ message, content: b64(JSON.stringify(obj)) }, sha ? { sha } : {})) });
  if (r.status === 401 || r.status === 403 || r.status === 404) throw new Error('GitHub에 저장할 권한이 없어요 (' + r.status + '). 토큰에 ' + repo.split('/')[1] + ' 저장소 Contents 쓰기 권한이 있는지 확인해 주세요.');
  if (!r.ok) throw new Error(path + ' 저장 실패 (' + r.status + ')');
}
async function sxExport(site, data) {
  const repo = repoOf(site); if (!repo) throw new Error('저널 주소에서 GitHub 저장소를 못 찾았어요.');
  const ghToken = await ghTok();
  if (!ghToken) throw new Error('확장 아이콘 → 설정에서 GitHub 토큰을 먼저 넣어 주세요.');
  const prev = await ghGet(repo, 'data/sheets.json', ghToken) || { pcs: [] };
  const hist = await ghGet(repo, 'data/sheets_history.json', ghToken) || { game: prev.game || site.match, pcs: {} };
  const now = new Date().toISOString(), changes = [], lv = [];
  (data.pcs || []).forEach(p => {
    if (p.comp) return;   // 동행 크리처는 레벨 기록 없이 시트만
    const o = prev.pcs.find(x => x.id === p.id);
    if (!o) return changes.push('새 캐릭터: ' + p.name + ' (Lv ' + sxLevel(p) + ')');
    const a = sxLevel(o), b = sxLevel(p);
    if (a && a !== b) { const t = p.name + ' ' + a + ' → ' + b; changes.push('레벨 ' + t); lv.push(t);
      (hist.pcs[p.id] = hist.pcs[p.id] || []).push({ level: a, saved: prev.exported || now, name: o.name, avatar: o.avatar, sheet: o.sheet, store: o.store, attrs: o.attrs, sheetVersion: o.sheetVersion }); }
  });
  if (!(data.pcs || []).length) throw new Error('읽은 시트가 없어요.');
  if (lv.length) await ghPut(repo, 'data/sheets_history.json', hist, '시트 기록: ' + lv.join(', '), ghToken);
  const out = { game: prev.game || site.match, campaign: data.cid, exported: now, skip: prev.skip || [], pcs: data.pcs };
  await ghPut(repo, 'data/sheets.json', out, '시트 내보내기 ' + now.slice(0, 10) + (changes.length ? ' · ' + changes.join(', ') : ''), ghToken);
  return { n: data.pcs.filter(p => !p.comp).length, nc: data.pcs.filter(p => p.comp).length, changes };
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  (async () => {
    if (msg.type === 'poll') {
      const sites = await getSites(), site = sites.find(s => msg.title && msg.title.includes(s.match));
      if (!site) return send({ ok: true, none: true });
      try { const out = await poll(site); out.url = site.url; send({ ok: true, out }); }
      catch (e) { if (e instanceof NoTk) return send({ ok: true, notk: true, url: site.url, match: site.match }); throw e; }
    } else if (msg.type === 'devtk') {
      // 저널 탭이 알려 준 로그인 표를 그 방 이름으로 보관 (바뀌면 Firebase 출입증도 새로)
      const sites = await getSites(), site = sites.find(s => msg.url && msg.url.startsWith(s.url.replace(/#.*$/, '')));
      if (!site || !msg.tk) return send({ ok: true });
      const k = 'tk_' + site.room, old = (await chrome.storage.local.get(k))[k];
      if (old !== msg.tk) { await chrome.storage.local.set({ [k]: msg.tk }); await chrome.storage.local.remove('fb_' + site.room); }
      send({ ok: true });
    } else if (msg.type === 'bag') {
      // Roll20 채팅의 '저널에 반영' 링크(#r20bag=…) → 열려 있는 저널 탭에 전달, 없으면 뒤에서 새 탭으로 열기 (저널이 알아서 반영)
      const sites = await getSites(), site = sites.find(s => msg.href && msg.href.startsWith(s.url.replace(/#.*$/, '')));
      if (!site) return send({ ok: true, nosite: true });
      const done = (await chrome.storage.local.get('bagDone')).bagDone || [];
      if (msg.id && done.includes(msg.id)) return send({ ok: true, dup: true });
      await chrome.storage.local.set({ bagDone: done.concat(msg.id ? [msg.id] : []).slice(-300) });
      const tabs = await chrome.tabs.query({ url: site.url.replace(/#.*$/, '').replace(/\/?$/, '/') + '*' });
      if (tabs.length) { chrome.tabs.sendMessage(tabs[0].id, { type: 'bag', data: msg.data }, () => void chrome.runtime.lastError); return send({ ok: true, sent: 'tab' }); }
      await chrome.tabs.create({ url: msg.href, active: false }); send({ ok: true, sent: 'new' });
    } else if (msg.type === 'r20here') {
      if (sender.tab) await chrome.storage.local.set({ lastR20: sender.tab.id }); send({ ok: true });
    } else if (msg.type === 'r20cmd') {
      // GM 패널 버튼 → Roll20 게임 탭 채팅으로
      const tabId = await r20Tab(sender);
      if (!tabId) return send({ ok: false, error: 'Roll20 게임 화면을 먼저 열어 주세요.' });
      const lines = String(msg.cmd || '').split(/\r?\n/).map(x => x.trim()).filter(Boolean).slice(0, 20);
      chrome.tabs.sendMessage(tabId, { type: 'sendChat', lines }, r => {
        if (chrome.runtime.lastError || !r || !r.ok) return send({ ok: false, error: (r && r.error) || 'Roll20 탭이 응답하지 않아요. 그 탭을 새로 고쳐 주세요.' });
        send({ ok: true });
      });
    } else if (msg.type === 'openJournal') {
      const tabId = await r20Tab(sender), t = tabId ? await chrome.tabs.get(tabId).catch(() => null) : null;
      const sites = await getSites(), site = t && sites.find(s => t.title && t.title.includes(s.match));
      if (!site) return send({ ok: false, error: '이 Roll20 게임과 연결된 저널을 못 찾았어요.' });
      const ex = await chrome.tabs.query({ url: site.url.replace(/#.*$/, '').replace(/\/?$/, '/') + '*' });
      if (ex.length) { await chrome.tabs.update(ex[0].id, { active: true }); await chrome.windows.update(ex[0].windowId, { focused: true }); }
      else await chrome.tabs.create({ url: site.url });
      send({ ok: true });
    } else if (msg.type === 'panelWin') {
      await chrome.storage.local.set({ panelMode: 'win' });
      const { panelWin } = await chrome.storage.local.get('panelWin');
      const w = panelWin ? await chrome.windows.get(panelWin).catch(() => null) : null;
      if (w) await chrome.windows.update(w.id, { focused: true });
      else { const nw = await chrome.windows.create({ url: chrome.runtime.getURL('panel.html?win=1'), type: 'popup', width: 380, height: 520 }); await chrome.storage.local.set({ panelWin: nw.id }); }
      send({ ok: true });
    } else if (msg.type === 'mapsWin') {   // 0.7.3: 맵·장면 창 (따로 띄운 창)
      const { mapsWin } = await chrome.storage.local.get('mapsWin');
      const w = mapsWin ? await chrome.windows.get(mapsWin).catch(() => null) : null;
      if (w) await chrome.windows.update(w.id, { focused: true });
      else { const nw = await chrome.windows.create({ url: chrome.runtime.getURL('maps.html'), type: 'popup', width: 980, height: 760 }); await chrome.storage.local.set({ mapsWin: nw.id }); }
      send({ ok: true });
    } else if (msg.type === 'mapsReq') {   // 맵·장면 창 → Roll20 게임 탭(GM)
      const tabs = await chrome.tabs.query({ url: 'https://app.roll20.net/editor/*' });
      if (!tabs.length) return send({ ok: false, error: 'Roll20 게임 화면(GM)을 먼저 열어 주세요.' });
      const order = tabs.sort((a, b2) => (b2.active ? 1 : 0) - (a.active ? 1 : 0));
      const tryTab = i => { if (i >= order.length) return send({ ok: false, error: 'Roll20 게임 탭이 응답하지 않아요. 그 탭을 새로 고쳐 주세요.' });
        chrome.tabs.sendMessage(order[i].id, { type: 'mapsReq', op: msg.op, args: msg.args }, r => { if (chrome.runtime.lastError || !r || !r.ok) return (r && r.error && i === order.length - 1) ? send(r) : tryTab(i + 1); send(r); }); };
      tryTab(0);
    } else if (msg.type === 'panelFloat') {
      await chrome.storage.local.set({ panelMode: 'open' });
      const { panelWin } = await chrome.storage.local.get('panelWin');
      if (panelWin) { await chrome.storage.local.remove('panelWin'); chrome.windows.remove(panelWin).catch(() => {}); }
      send({ ok: true });
    } else if (msg.type === 'archiveSave') {
      // Roll20 게임 탭 → 캠페인 번호 → 채팅 기록 페이지를 뒤에서 열어 이번 세션 부분만 잘라 → 저널 세션 로그
      const tid = await r20Tab(sender), tab = tid ? await chrome.tabs.get(tid).catch(() => null) : null;
      if (!tab) return send({ ok: false, error: 'Roll20 게임 화면을 먼저 열어 주세요.' });
      const sites = await getSites(), site = sites.find(s => tab.title && tab.title.includes(s.match));
      if (!site) return send({ ok: false, error: '이 Roll20 게임과 연결된 저널을 못 찾았어요 (확장 설정의 제목 글자 확인).' });
      const out = await archiveGrab(tab.id);
      if (out.error) return send({ ok: false, error: out.error });
      await chrome.storage.local.set({ ['pendLog_' + site.room]: { html: out.html, n: out.n, date: out.date, t: Date.now() } });
      await chrome.tabs.create({ url: site.url.replace(/#.*$/, '') + '#r20log', active: true });
      send({ ok: true, n: out.n });
    } else if (msg.type === 'getLog') {
      const sites = await getSites(), site = sites.find(s => msg.url && msg.url.startsWith(s.url.replace(/#.*$/, '')));
      if (!site) return send({ ok: false });
      const k = 'pendLog_' + site.room, p = (await chrome.storage.local.get(k))[k];
      if (!p || Date.now() - p.t > 6 * 3600000) return send({ ok: false });
      await chrome.storage.local.remove(k); send({ ok: true, log: p });
    } else if (msg.type === 'journalCmd') {
      // 저널 탭이 보낸 거래 명령 → 자동 반영이 켜져 있으면 그 게임의 Roll20 탭 채팅에 입력
      const st = await chrome.storage.sync.get('auto'); if (!st.auto) return send({ ok: true, off: true });
      const sites = await getSites(), site = sites.find(s => msg.url && msg.url.startsWith(s.url.replace(/#.*$/, '')));
      if (!site) return send({ ok: true, nosite: true });
      const tabs = (await chrome.tabs.query({ url: 'https://app.roll20.net/editor/*' })).filter(t => (t.title || '').includes(site.match));
      if (!tabs.length) { chrome.notifications.create({ type: 'basic', iconUrl: 'icon128.png', title: 'Roll20 저널 도우미', message: '거래가 있었지만 Roll20 탭(' + site.match + ')이 없어 반영하지 못했어요.', priority: 1 }); return send({ ok: true, notab: true }); }
      chrome.tabs.sendMessage(tabs[0].id, { type: 'chatCmd', cmd: msg.cmd }, () => void chrome.runtime.lastError); send({ ok: true, sent: true });
    } else if (msg.type === 'sxSite') {   // 0.7.6: 지금 저널에 올라가 있는 레벨 (레벨 변화 알림용)
      const sites = await getSites(), site = sites.find(s => msg.title && msg.title.includes(s.match)), repo = repoOf(site);
      if (!repo) return send({ ok: false });
      const ghToken = await ghTok();
      const prev = await ghGet(repo, 'data/sheets.json', ghToken).catch(() => null);
      if (!prev) return send({ ok: false });
      const base = {}; (prev.pcs || []).forEach(p => { base[p.id] = sxLevel(p); });
      send({ ok: true, base, skip: prev.skip || [] });
    } else if (msg.type === 'sxNames') {   // 0.8.0: 저널에 PC로 등록한 이름 (저널 서버에서)
      const sites = await getSites(), site = sites.find(s => msg.title && msg.title.includes(s.match));
      if (!site || !site.exec) return send({ ok: true, names: [] });
      try { const tk = (await chrome.storage.local.get('tk_' + site.room))['tk_' + site.room] || ''; const r = await fetch(site.exec + '?action=load' + (tk ? '&tk=' + encodeURIComponent(tk) : ''), { redirect: 'follow' }); let d = await r.json(); if (d && d.data) d = d.data; if (typeof d === 'string') d = JSON.parse(d);
        send({ ok: true, names: ((d && d.boardTex && d.boardTex.pcs) || []).filter(p => p && p.name).map(p => [p.name].concat(p.r20 ? [p.r20] : [], Array.isArray(p.aliases) ? p.aliases : [])) }); }   // 0.8.2: 별명도 같이 (Roll20에서 별명을 쓰는 PC)
      catch (e) { send({ ok: true, names: [] }); }
    } else if (msg.type === 'sxExport') {
      const sites = await getSites(), site = sites.find(s => msg.title && msg.title.includes(s.match));
      if (!site) return send({ ok: false, error: '이 Roll20 게임과 연결된 저널을 못 찾았어요 (확장 설정의 제목 글자 확인).' });
      const r = await sxExport(site, msg.data || {});
      send(Object.assign({ ok: true, url: site.url }, r));
    } else if (msg.type === 'notify') {
      chrome.notifications.create({ type: 'basic', iconUrl: 'icon128.png', title: msg.title, message: msg.message, priority: 2 });
      if (msg.badge != null) { chrome.action.setBadgeText({ text: msg.badge }); chrome.action.setBadgeBackgroundColor({ color: '#b3261e' }); }
      send({ ok: true });
    } else if (msg.type === 'badge') { chrome.action.setBadgeText({ text: msg.text || '' }); chrome.action.setBadgeBackgroundColor({ color: '#b3261e' }); send({ ok: true }); }
  })().catch(e => send({ ok: false, error: String(e && e.message || e) }));
  return true;
});

// ---- GM 패널 설정도 크롬 계정에 (0.7.7): PC방처럼 다른 컴퓨터에서 확장을 새로 깔아도 버튼·탭이 그대로 ----
//  동기화 저장소는 항목 하나에 8KB까지라 잘라서 넣어요 (pcfg_n = 조각 수, pcfg_0..)
const SYNC_KEYS = ['panelCfg', 'panelAdded', 'panelTab', 'hideRaw'];
let mirrorT = null;
async function mirrorUp() {
  const L = await chrome.storage.local.get(SYNC_KEYS);
  const s = JSON.stringify(L), parts = [];
  for (let i = 0; i < s.length; i += 1500) parts.push(s.slice(i, i + 1500));
  const old = (await chrome.storage.sync.get('pcfg_n')).pcfg_n || 0, obj = { pcfg_n: parts.length, pcfg_t: Date.now() };
  parts.forEach((p, i) => { obj['pcfg_' + i] = p; });
  await chrome.storage.sync.set(obj);
  const rm = []; for (let i = parts.length; i < old; i++) rm.push('pcfg_' + i); if (rm.length) await chrome.storage.sync.remove(rm);
}
let restored = false;
async function mirrorDown() {
  // 이 컴퓨터에 깐 뒤 처음 한 번만 계정에서 받아 와요 (그 전에 패널이 기본값을 써 넣었어도 계정 것이 우선)
  if ((await chrome.storage.local.get('pcfgRestored')).pcfgRestored) { restored = true; return; }
  const n = (await chrome.storage.sync.get('pcfg_n')).pcfg_n;
  if (n) { const keys = []; for (let i = 0; i < n; i++) keys.push('pcfg_' + i);
    const S = await chrome.storage.sync.get(keys);
    try { const o = JSON.parse(keys.map(k => S[k] || '').join('')); if (o && o.panelCfg) await chrome.storage.local.set(o); } catch (e) {} }
  await chrome.storage.local.set({ pcfgRestored: 1 }); restored = true;
}
chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && SYNC_KEYS.some(k => ch[k])) { clearTimeout(mirrorT); mirrorT = setTimeout(() => { if (restored) mirrorUp().catch(() => {}); }, 3000); } });
chrome.runtime.onInstalled.addListener(() => { mirrorDown().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { mirrorDown().catch(() => {}); });
mirrorDown().catch(() => {});
