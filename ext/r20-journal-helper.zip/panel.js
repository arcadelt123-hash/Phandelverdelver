// Roll20 저널 도우미 — GM 패널 (게임 화면 위 패널과 따로 띄운 창에서 같이 써요)
(function () {
  'use strict';
  const IS_WIN = /[?&]win=1/.test(location.search);
  const $ = id => document.getElementById(id);
  const clone = o => JSON.parse(JSON.stringify(o));
  let cfg = null, cur = 0, editing = false, saveT = null;

  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function msg(t, err) { const m = $('msg'); m.textContent = t; m.className = err ? 'err' : ''; m.title = t; }
  function valid(c) { return Array.isArray(c) && c.every(t => t && typeof t.name === 'string' && Array.isArray(t.buttons)); }
  function save() { clearTimeout(saveT); saveT = setTimeout(() => chrome.storage.local.set({ panelCfg: cfg, panelTab: cur }), 300); }

  function load(cb) {
    chrome.storage.local.get(['panelCfg', 'panelTab', 'panelAdded'], r => {
      cfg = valid(r.panelCfg) ? r.panelCfg : clone(PANEL_DEFAULTS);
      // 0.6.2: 쉬는 시간 5/10/15분·+5분 버튼 → '쉬는 시간'(직접 입력, 기본 10분·시각 가능) 하나로 (예전 기본 버튼 그대로일 때만)
      const OLD = ['!쉬는시간 5', '!쉬는시간 10', '!쉬는시간 15', '!쉬는시간 더 5'];
      cfg.forEach(t => { const i = t.buttons.findIndex(b => OLD.includes(b.cmd)); if (i < 0) return;
        t.buttons = t.buttons.filter((b, j) => j === i || !OLD.includes(b.cmd));
        t.buttons.splice(i, 1, { label: '쉬는 시간', cmd: '!쉬는시간 ?{몇 분 쉴까요? (또는 끝나는 시각, 예: 21:30)|10}' }, { label: '쉬는 시간 바꾸기', cmd: '!쉬는시간 바꾸기 ?{남은 시간: 몇 분, 또는 끝나는 시각 (예: 21:30)|5}' });
        if (t.buttons.filter(b => /^!쉬는시간 바꾸기/.test(b.cmd)).length > 1) { let seen = false; t.buttons = t.buttons.filter(b => { if (!/^!쉬는시간 바꾸기/.test(b.cmd)) return true; if (seen) return false; seen = true; return true; }); }
        chrome.storage.local.set({ panelCfg: cfg }); });
      // 0.6.4: '재개'가 쉬는 시간도 끝내요 → 예전 '쉬는 시간 끝' 버튼은 빼고, 재개 버튼 이름만 바꿔요
      if (cfg.some(t => t.buttons.some(b => b.cmd === '!재개')) && cfg.some(t => t.buttons.some(b => b.cmd === '!쉬는시간 끝'))) {
        cfg.forEach(t => { t.buttons = t.buttons.filter(b => b.cmd !== '!쉬는시간 끝'); t.buttons.forEach(b => { if (b.cmd === '!재개' && b.label === '재개') b.label = '재개 (쉬는 시간도 끝)'; }); });
        chrome.storage.local.set({ panelCfg: cfg });
      }
      // 0.6.7: 새 탭 '카드·연출'을 한 번만 끼워 넣어요 (직접 지운 뒤에는 다시 안 넣어요)
      const added = Array.isArray(r.panelAdded) ? r.panelAdded : [];
      if (!added.includes('card1')) {
        const d = PANEL_DEFAULTS.find(x => x.name === '카드·연출');
        if (d && !cfg.some(t => t.name === d.name)) { const si = cfg.findIndex(t => t.name === '설정'); cfg.splice(si >= 0 ? si : cfg.length, 0, clone(d)); }
        added.push('card1'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('fx1')) {   // 0.6.8: 애니메이션 효과 버튼을 '카드·연출' 탭에 한 번만
        const t = cfg.find(x => x.name === '카드·연출');
        if (t && !t.buttons.some(b => /^!효과/.test(b.cmd))) t.buttons.splice(3, 0, { label: '애니메이션 효과', cmd: '!효과' }, { label: '효과 시험 (선택 토큰)', cmd: '!효과 시험 ?{효과 이름 (fx 뒤의 글자)}' });
        added.push('fx1'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('sheets1')) {   // 0.7.6: 'PC 시트 → 저널' 버튼을 세션·저널 탭에 한 번만
        const t = cfg.find(x => x.name === '세션·저널') || cfg[0];
        if (t && !cfg.some(x => x.buttons.some(b => b.cmd === '@ext:sheets'))) t.buttons.push({ label: '시트 → 저널 내보내기', cmd: '@ext:sheets' });
        added.push('sheets1'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('hideraw1')) {   // 0.6.8: '원본 귓속말 숨기기' 버튼을 설정 탭에 한 번만
        const t = cfg.find(x => x.name === '설정') || cfg[cfg.length - 1];
        if (t && !cfg.some(x => x.buttons.some(b => b.cmd === '@ext:hideraw'))) t.buttons.push({ label: '원본 귓속말 숨기기 켜기/끄기', cmd: '@ext:hideraw' });
        added.push('hideraw1'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('ring1')) {   // 0.6.9: 상태 고리·범위 템플릿·몸집 크기 버튼을 '카드·연출' 탭에 한 번만
        const t = cfg.find(x => x.name === '카드·연출');
        if (t && !t.buttons.some(b => /^!표식/.test(b.cmd))) {
          const at = t.buttons.findIndex(b => /^!효과 시험/.test(b.cmd));
          t.buttons.splice(at >= 0 ? at + 1 : t.buttons.length, 0, { label: '상태 고리 (표식 애니메이션)', cmd: '!표식' }, { label: '범위 템플릿 켜기/끄기', cmd: '!범위 템플릿' },
            { label: '몸집별 효과 크기', cmd: '!효과 몸집 ?{몸집|아주 작음,tiny|작음·중간,medium|큼,large|거대,huge|초대형,gargantuan} ?{크기 ft|7}' });
        }
        added.push('ring1'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('v070')) {   // 0.7.0: 카드 미리보기·아이콘 짝 → 링크, 효과 시험·피 자국 빼기, 테마 목록·적 HP(바만) 새로
        const D = (PANEL_DEFAULTS.find(x => x.name === '카드·연출') || { buttons: [] }).buttons, dOf = re => D.find(b => re.test(b.cmd));
        cfg.forEach(t => {
          const nb = []; let iconAt = -1;
          t.buttons.forEach(b => { const c = String(b.cmd || '');
            if (/^!효과 시험/.test(c) || /^!pc blood /.test(c)) return;
            if (/^!주문아이콘(\s|$)/.test(c)) { if (iconAt < 0) { iconAt = nb.length; nb.push(Object.assign({}, dOf(/spell_icons\.html/))); } return; }
            if (c === '!pc test' && /미리보기/.test(b.label || '')) return nb.push(Object.assign({}, dOf(/^@ext:open https:\/\/claude\.ai/)));
            if (/^!pc theme \?\{/.test(c)) return nb.push(Object.assign({}, b, { cmd: dOf(/^!pc theme/).cmd }));
            if (/^!pc npchp \?\{/.test(c)) return nb.push(Object.assign({}, b, { cmd: dOf(/^!pc npchp/).cmd }));
            nb.push(b); });
          t.buttons = nb.filter(b => b && b.cmd);
        });
        added.push('v070'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('sum1')) {   // 0.7.1: 소환수 맡기기 · 동행 버튼
        const t = cfg.find(x => x.name === '카드·연출');
        if (t && !t.buttons.some(b => /^!(소환|펫)/.test(b.cmd))) { const at = t.buttons.findIndex(b => b.cmd === '!연출'); t.buttons.splice(at >= 0 ? at + 1 : t.buttons.length, 0, { label: '소환수 맡기기 (선택 토큰)', cmd: '!소환' }, { label: '동행 등록·목록 (선택 토큰)', cmd: '!동행' }); }
        added.push('sum1'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('v072')) {   // 0.7.2: '펫' → '동행' 이름 바꾸기 · [맵 목록] 버튼을 첫 탭 맨 앞에
        cfg.forEach(t => t.buttons.forEach(b => { if (b.cmd === '!펫' || /^펫 등록/.test(b.label || '')) { b.cmd = '!동행'; b.label = String(b.label || '').replace(/^펫/, '동행'); } }));
        if (!cfg.some(t => t.buttons.some(b => b.cmd === '@ext:maps')) && cfg[0]) cfg[0].buttons.unshift({ label: '맵 목록 (Alt+M)', cmd: '@ext:maps' });
        added.push('v072'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('v073')) {   // 0.7.3: '범위 주문' 버튼 빼기 (자로 깔기·시트 주문으로 충분) · 맵·장면 창 · 개요서/그림 라이브러리 떼어내기
        cfg.forEach(t => { t.buttons = t.buttons.filter(b => !(/^!범위 \?\{모양/.test(b.cmd || ''))); });
        if (cfg[0] && !cfg.some(t => t.buttons.some(b => b.cmd === '@ext:mapswin'))) { const i = cfg[0].buttons.findIndex(b => b.cmd === '@ext:maps'); cfg[0].buttons.splice(i >= 0 ? i + 1 : 0, 0, { label: '맵·장면 창 (따로)', cmd: '@ext:mapswin' }, { label: '개요서 떼어내기 (Alt+K)', cmd: '@ext:float comp' }, { label: '그림 라이브러리 떼어내기 (Alt+L)', cmd: '@ext:float art' }); }
        added.push('v073'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('v074')) {   // 0.7.4: 도구 창(맵·개요서·그림 라이브러리 한 창) · 장면 설정 창은 따로
        cfg.forEach(t => t.buttons.forEach(b => { if (b.cmd === '@ext:mapswin') b.label = '장면 설정 창'; }));
        if (cfg[0] && !cfg.some(t => t.buttons.some(b => /^@ext:tools/.test(b.cmd)))) { const i = cfg[0].buttons.findIndex(b => b.cmd === '@ext:maps'); cfg[0].buttons.splice(i >= 0 ? i + 1 : 0, 0, { label: '도구 창 (맵·개요서·그림)', cmd: '@ext:tools' }); }
        if (cfg[0] && !cfg.some(t => t.buttons.some(b => b.cmd === '@ext:mapswin'))) cfg[0].buttons.push({ label: '장면 설정 창', cmd: '@ext:mapswin' });
        added.push('v074'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      if (!added.includes('v075')) {   // 0.7.5: 상태 한눈에 버튼 (걸린 상태·지속시간·광원)
        if (!cfg.some(t => t.buttons.some(b => b.cmd === '!상태판'))) { const t = cfg.find(x => x.buttons.some(b => b.cmd === '!상태')) || cfg.find(x => x.name === '전투') || cfg[0]; const i = t.buttons.findIndex(b => b.cmd === '!상태'); t.buttons.splice(i >= 0 ? i + 1 : t.buttons.length, 0, { label: '상태 한눈에 (걸린 상태·지속시간·광원)', cmd: '!상태판' }); }
        added.push('v075'); chrome.storage.local.set({ panelCfg: cfg, panelAdded: added });
      }
      cur = Math.min(Math.max(0, Number(r.panelTab) || 0), Math.max(0, cfg.length - 1));
      cb && cb();
    });
  }

  function renderTabs() {
    $('tabs').innerHTML = cfg.map((t, i) => `<button data-i="${i}" class="${i === cur ? 'on' : ''}">${esc(t.name || '(이름 없음)')}</button>`).join('') +
      (editing ? '<button data-add="1" title="탭 추가">+ 탭</button>' : '');
  }

  function renderView() {
    const t = cfg[cur];
    if (!t) { $('main').innerHTML = '<div class="help">탭이 없어요. [편집]에서 탭을 추가해 주세요.</div>'; return; }
    $('main').innerHTML = t.buttons.length
      ? '<div class="grid">' + t.buttons.map((b, i) => `<button data-b="${i}" class="${/^@ext:/.test(b.cmd || '') ? 'ext' : ''}" title="${esc(b.cmd)}">${esc(b.label || '(이름 없음)')}</button>`).join('') + '</div>'
      : '<div class="help">버튼이 없어요. [편집]에서 추가해 주세요.</div>';
  }

  function renderEdit() {
    const t = cfg[cur];
    if (!t) { $('main').innerHTML = '<div class="help">탭이 없어요. 위의 [+ 탭]을 눌러 주세요.</div>' + toolsBar(); return; }
    $('main').innerHTML =
      `<div class="ed-tab">탭 이름 <input id="tname" value="${esc(t.name)}">` +
      `<button class="sm" data-tmv="-1" title="탭을 왼쪽으로">←</button><button class="sm" data-tmv="1" title="탭을 오른쪽으로">→</button>` +
      `<button class="sm del" data-tdel="1">탭 삭제</button></div>` +
      t.buttons.map((b, i) => `<div class="row" data-r="${i}"><div class="top"><input data-f="label" value="${esc(b.label)}" placeholder="버튼 이름">` +
        `<button class="sm" data-mv="-1" title="위로">↑</button><button class="sm" data-mv="1" title="아래로">↓</button>` +
        `<select class="sm" data-to title="다른 탭으로 옮기기"><option value="">탭 이동</option>${cfg.map((x, j) => j === cur ? '' : `<option value="${j}">${esc(x.name)}</option>`).join('')}</select>` +
        `<button class="sm del" data-del="1" title="버튼 삭제">×</button></div>` +
        `<textarea data-f="cmd" rows="2" placeholder="!명령 (여러 줄이면 한 줄씩 차례로 보내요)">${esc(b.cmd)}</textarea></div>`).join('') +
      `<button class="sm" id="badd">+ 버튼 추가</button>` +
      `<div class="help">명령은 채팅에 직접 치는 것과 같아요. <code>?{질문|기본값}</code> 입력 창, <code>[[2d6]]</code> 주사위, <code>@{target|...}</code> 토큰 클릭이 다 돼요. ` +
      `<code>@ext:savelog</code> = 세션 채팅을 저널 로그로, <code>@ext:journal</code> = 저널 열기, <code>@ext:sheets</code> = PC 시트를 저널로 내보내기, <code>@ext:hideraw</code> = 원본 귓속말 숨기기 켜기/끄기, <code>@ext:open https://주소</code> = 새 탭으로 열기.</div>` + toolsBar();
  }
  function toolsBar() {
    return `<div class="bar"><button class="sm" id="exp">내보내기 (복사)</button><button class="sm" id="imp">가져오기 (붙여넣기)</button>` +
      `<button class="sm" id="addmiss" title="지운 기본 버튼 중 다시 넣고 싶은 것">기본 버튼 다시 넣기</button><button class="sm del" id="reset">전부 기본값으로</button></div>`;
  }

  function render() { renderTabs(); editing ? renderEdit() : renderView(); $('edit').textContent = editing ? '완료' : '편집'; }

  // ---- 명령 보내기 ----
  function run(b, el) {
    const cmd = String(b.cmd || '').trim();
    if (!cmd) return msg('명령이 비어 있어요. [편집]에서 넣어 주세요.', true);
    if (/^@ext:savelog/.test(cmd)) {
      msg('Roll20 채팅 기록 읽는 중… (몇 초)');
      return chrome.runtime.sendMessage({ type: 'archiveSave' }, r => {
        if (chrome.runtime.lastError || !r || !r.ok) return msg('실패: ' + ((r && r.error) || '확장을 다시 불러와 주세요'), true);
        msg('저널을 열었어요 · 채팅 ' + r.n + '개');
      });
    }
    if (/^@ext:hideraw/.test(cmd)) return chrome.storage.local.get('hideRaw', r => { const on = r.hideRaw === false; chrome.storage.local.set({ hideRaw: on }); msg(on ? '원본 귓속말 숨기기: 켜짐' : '원본 귓속말 숨기기: 꺼짐 (다시 보여요)'); });
    if (/^@ext:open\s+https:\/\//.test(cmd)) { const u = cmd.replace(/^@ext:open\s+/, '').trim(); try { chrome.tabs.create({ url: u }); } catch (e) { window.open(u, '_blank', 'noopener'); } return msg('새 탭으로 열었어요'); }
    if (/^@ext:mapswin/.test(cmd)) return chrome.runtime.sendMessage({ type: 'mapsWin' }, () => msg('장면 설정 창을 열었어요'));
    if (/^@ext:journal/.test(cmd)) return chrome.runtime.sendMessage({ type: 'openJournal' }, r => msg(r && r.ok ? '저널을 열었어요' : ((r && r.error) || '저널을 못 찾았어요'), !(r && r.ok)));
    chrome.runtime.sendMessage({ type: 'r20cmd', cmd }, r => {
      if (chrome.runtime.lastError || !r || !r.ok) return msg((r && r.error) || 'Roll20 게임 탭을 못 찾았어요.', true);
      msg('보냄: ' + (b.label || cmd)); if (el) { el.classList.add('sent'); setTimeout(() => el.classList.remove('sent'), 700); }
    });
  }

  // ---- 이벤트 ----
  $('tabs').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.add) { cfg.push({ name: '새 탭', buttons: [] }); cur = cfg.length - 1; save(); return render(); }
    cur = Number(b.dataset.i) || 0; save(); render();
  });
  $('main').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const t = cfg[cur];
    if (!editing) { if (b.dataset.b != null && t) run(t.buttons[Number(b.dataset.b)], b); return; }
    const row = b.closest('.row'), ri = row ? Number(row.dataset.r) : -1;
    if (b.dataset.mv && ri >= 0) { const j = ri + Number(b.dataset.mv); if (j < 0 || j >= t.buttons.length) return; const x = t.buttons.splice(ri, 1)[0]; t.buttons.splice(j, 0, x); save(); return render(); }
    if (b.dataset.del && ri >= 0) { if (!confirm(`'${t.buttons[ri].label}' 버튼을 지울까요?`)) return; t.buttons.splice(ri, 1); save(); return render(); }
    if (b.dataset.tmv) { const j = cur + Number(b.dataset.tmv); if (j < 0 || j >= cfg.length) return; const x = cfg.splice(cur, 1)[0]; cfg.splice(j, 0, x); cur = j; save(); return render(); }
    if (b.dataset.tdel) { if (!confirm(`'${t.name}' 탭과 그 안의 버튼 ${t.buttons.length}개를 지울까요?`)) return; cfg.splice(cur, 1); cur = Math.max(0, cur - 1); save(); return render(); }
    if (b.id === 'badd') { t.buttons.push({ label: '새 버튼', cmd: '!' }); save(); render(); const rows = document.querySelectorAll('.row'); const last = rows[rows.length - 1]; if (last) { last.scrollIntoView(); last.querySelector('input').select(); } return; }
    if (b.id === 'exp') { const s = JSON.stringify(cfg, null, 1); navigator.clipboard.writeText(s).then(() => msg('설정을 복사했어요. 메모장 등에 붙여 두세요.'), () => { prompt('아래 내용을 복사해 두세요', s); }); return; }
    if (b.id === 'imp') { const s = prompt('내보내기로 복사해 둔 설정을 붙여넣어 주세요'); if (!s) return; try { const c = JSON.parse(s); if (!valid(c)) throw 0; cfg = c; cur = 0; save(); render(); msg('설정을 가져왔어요.'); } catch (x) { msg('형식이 맞지 않아요.', true); } return; }
    if (b.id === 'reset') { if (!confirm('모든 탭과 버튼을 처음 상태로 되돌릴까요? (직접 만든 버튼은 사라져요)')) return; cfg = clone(PANEL_DEFAULTS); cur = 0; save(); render(); msg('기본값으로 되돌렸어요.'); return; }
    if (b.id === 'addmiss') {
      const have = new Set(); cfg.forEach(x => x.buttons.forEach(y => have.add(y.cmd)));
      let n = 0; PANEL_DEFAULTS.forEach(d => { const miss = d.buttons.filter(y => !have.has(y.cmd)); if (!miss.length) return; let t2 = cfg.find(x => x.name === d.name); if (!t2) { t2 = { name: d.name, buttons: [] }; cfg.push(t2); } miss.forEach(y => { t2.buttons.push(clone(y)); n++; }); });
      save(); render(); msg(n ? `기본 버튼 ${n}개를 다시 넣었어요.` : '빠진 기본 버튼이 없어요.'); return;
    }
  });
  $('main').addEventListener('input', e => {
    const t = cfg[cur]; if (!t) return;
    if (e.target.id === 'tname') { t.name = e.target.value; save(); const tb = document.querySelector(`#tabs button[data-i="${cur}"]`); if (tb) tb.textContent = t.name || '(이름 없음)'; return; }
    const row = e.target.closest('.row'); if (!row || !e.target.dataset.f) return;
    t.buttons[Number(row.dataset.r)][e.target.dataset.f] = e.target.value; save();
  });
  $('main').addEventListener('change', e => {
    if (e.target.dataset.to === undefined || e.target.value === '') return;
    const t = cfg[cur], row = e.target.closest('.row'), ri = Number(row.dataset.r), j = Number(e.target.value);
    const x = t.buttons.splice(ri, 1)[0]; cfg[j].buttons.push(x); save(); render(); msg(`'${x.label}'을(를) '${cfg[j].name}' 탭으로 옮겼어요.`);
  });
  $('edit').onclick = () => { editing = !editing; render(); };
  $('mode').textContent = IS_WIN ? '게임 화면 위로' : '창으로';
  $('mode').onclick = () => chrome.runtime.sendMessage({ type: IS_WIN ? 'panelFloat' : 'panelWin' }, () => { if (IS_WIN) window.close(); });

  // 다른 곳(창 ↔ 게임 화면 패널)에서 고치면 같이 바뀌게
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || !ch.panelCfg || editing) return;
    if (valid(ch.panelCfg.newValue)) { cfg = ch.panelCfg.newValue; cur = Math.min(cur, Math.max(0, cfg.length - 1)); render(); }
  });
  load(render);
})();
