// Roll20 저널 도우미 — GM 패널 기본 버튼
// 버튼 하나 = { label: 보이는 이름, cmd: Roll20 채팅에 보낼 명령 }
//  - cmd 는 채팅에 직접 치는 것과 같아요: ?{질문|기본값} (입력 창), [[2d6]] (주사위), @{target|...} (토큰 클릭) 모두 그대로 돼요.
//  - 여러 줄이면 한 줄씩 차례로 보내요 (매크로처럼).
//  - '@ext:' 로 시작하면 확장이 직접 하는 일: @ext:savelog (세션 채팅 → 저널), @ext:journal (저널 열기), @ext:sheets (PC 시트 → 저널)
const PANEL_DEFAULTS = [
  { name: '진행', buttons: [
    { label: '맵 목록 (Alt+M)', cmd: '@ext:maps' },
    { label: '도구 창 (맵·개요서·그림)', cmd: '@ext:tools' },
    { label: '장면 설정 창', cmd: '@ext:mapswin' },
    { label: '개요서 떼어내기 (Alt+K)', cmd: '@ext:float comp' },
    { label: '그림 라이브러리 떼어내기 (Alt+L)', cmd: '@ext:float art' },
    { label: '일시정지', cmd: '!일시정지' },
    { label: '재개 (쉬는 시간도 끝)', cmd: '!재개' },
    { label: '쉬는 시간', cmd: '!쉬는시간 ?{몇 분 쉴까요? (또는 끝나는 시각, 예: 21:30)|10}' },
    { label: '쉬는 시간 바꾸기', cmd: '!쉬는시간 바꾸기 ?{남은 시간: 몇 분, 또는 끝나는 시각 (예: 21:30)|5}' },
    { label: '장면 목록', cmd: '!장면' },
    { label: '묘사', cmd: '!묘사 ?{묘사}' },
    { label: 'Mod 메뉴', cmd: '!pc' }
  ] },
  { name: '전투', buttons: [
    { label: 'GM 굴림 귓속말 켜기/끄기', cmd: '!pc set gmwhisper' },
    { label: '적 이니셔티브', cmd: '!이니셔티브' },
    { label: '이니 (같은 이름 묶기)', cmd: '!이니셔티브 묶음' },
    { label: '턴 순서 정렬', cmd: '!이니셔티브 정렬' },
    { label: '피해', cmd: '!피해 [[?{피해량 (주사위식 가능)|0}]] ?{절반?|아니오, |예,절반}' },
    { label: '회복', cmd: '!회복 [[?{회복량|0}]]' },
    { label: '상태이상', cmd: '!상태' },
    { label: '상태 한눈에 (걸린 상태·지속시간·광원)', cmd: '!상태판' },
    { label: '상태 전부 해제', cmd: '!상태 해제' },
    { label: '적 HP 다시 굴림', cmd: '!적HP' },
    { label: '전설 행동', cmd: '!전설' },
    { label: '전투 종료', cmd: '!전투종료' }
  ] },
  { name: '토큰', buttons: [
    { label: '토큰으로 말하기', cmd: '!말 ?{말 (선택한 토큰 이름으로)}' },
    { label: '토큰 행동', cmd: '!행동 ?{행동 (예: 침을 뱉는다)}' },
    { label: '대사 카드', cmd: '!대사 ?{대사}' },
    { label: '이름표 보이기/숨기기', cmd: '!이름' },
    { label: '번호 붙이기', cmd: '!이름 번호' },
    { label: '이름 바꾸기', cmd: '!이름 ?{새 이름 (여러 개면 뒤에 번호)}' },
    { label: '광원', cmd: '!광원' },
    { label: '영감', cmd: '!영감' }
  ] },
  { name: '시간·날씨', buttons: [
    { label: '다음 시간대', cmd: '!시간 다음' },
    { label: '다음 날', cmd: '!시간 다음날' },
    { label: '날짜 +N일', cmd: '!시간 ?{며칠 지났나요? (뒤로는 -2처럼)|1}' },
    { label: '날짜 모두에게', cmd: '!시간 공개' },
    { label: '날씨 다시 굴림', cmd: '!시간 날씨 굴림' },
    { label: '날씨 직접', cmd: '!시간 날씨 ?{날씨 이름}' },
    { label: '여행', cmd: '!여행 ?{거리 (마일)|12} ?{속도|보통|빠름|느림}' },
    { label: '짧은 휴식', cmd: '!짧은휴식' },
    { label: '긴 휴식', cmd: '!긴휴식' },
    { label: '시간 설정', cmd: '!시간' }
  ] },
  { name: '세션·저널', buttons: [
    { label: '세션 시작', cmd: '!세션시작' },
    { label: '세션 정리', cmd: '!세션정리' },
    { label: '채팅 → 저널 로그', cmd: '@ext:savelog' },
    { label: '전리품', cmd: '!전리품 ?{받는 캐릭터}|?{아이템 (돈은 50 gp처럼)}|?{개수|1}' },
    { label: '상점 정리', cmd: '!상점' },
    { label: '모두에게 상점 링크', cmd: '!상점열기 ?{상점 이름 (비우면 첫 상점)| }' },
    { label: '파티 현황판', cmd: '!현황판' },
    { label: '소모품 정산', cmd: '!탄약정산' },
    { label: '저널 열기', cmd: '@ext:journal' },
    { label: '시트 → 저널 내보내기', cmd: '@ext:sheets' }
  ] },
  // 판델버 게임에 깔려 있는 다른 Mod들 (없는 게임에서는 눌러도 아무 일도 안 일어나요)
  { name: '다른 Mod', buttons: [
    { label: '턴 넘기기 (TurnMarker)', cmd: '!eot' },
    { label: '라운드 초기화', cmd: '!tm reset ?{몇 라운드부터?|0}' },
    { label: '현재 차례 토큰 핑', cmd: '!tm ping-target' },
    { label: '선택 토큰 이니 굴림 (GroupInit)', cmd: '!group-init' },
    { label: '이니 다시 굴림', cmd: '!group-init --reroll' },
    { label: '이니 정렬', cmd: '!group-init --sort' },
    { label: '이니 비우기', cmd: '!group-init --clear' },
    { label: '단체 판정 (GroupCheck)', cmd: '!group-check ?{판정|민첩 내성,--Dexterity Save|건강 내성,--Constitution Save|지혜 내성,--Wisdom Save|근력 내성,--Strength Save|지능 내성,--Intelligence Save|매력 내성,--Charisma Save|지각,--Perception|은신,--Stealth|통찰,--Insight|수사,--Investigation}' },
    { label: '단체 판정 (GM에게만)', cmd: '!group-check --whisper ?{판정|민첩 내성,--Dexterity Save|건강 내성,--Constitution Save|지혜 내성,--Wisdom Save|근력 내성,--Strength Save|지능 내성,--Intelligence Save|매력 내성,--Charisma Save|지각,--Perception|은신,--Stealth|통찰,--Insight|수사,--Investigation}' },
    { label: '판정 목록 보기', cmd: '!group-check-config --show' },
    { label: '말하는 캐릭터 바꾸기', cmd: '!!?{캐릭터 이름 (일부만 써도 돼요)}' },
    { label: '말하는 사람 GM으로', cmd: '!switch' },
    { label: '잡담 (작은 글씨)', cmd: '! ?{잡담}' },
    { label: '설명 (/desc)', cmd: '!d ?{설명}' },
    { label: '무작위 고르기', cmd: 'choice[?{고를 것들 (쉼표로 구분)|왼쪽, 오른쪽}]' },
    { label: '토큰 숨기기 (GM 레이어)', cmd: '!token-mod --set layer|gmlayer' },
    { label: '토큰 꺼내기 (토큰 레이어)', cmd: '!token-mod --set layer|objects' },
    { label: 'HP 바 공개/숨김', cmd: '!token-mod --flip showplayers_bar1' }
  ] },
  { name: '카드·연출', buttons: [
    { label: '카드 테마 바꾸기', cmd: '!pc theme ?{테마|양피지,parchment|어두운 달,darkmoon|노을빛 순간,sunset|던전,dungeon|트와일라잇 (장미),twrose|트와일라잇 (복숭아),twpeach|트와일라잇 (금빛),twgold|트와일라잇 (보라),twviolet|선술집 (밝은 양피지),tavernl|선술집 (짙은 양피지),tavernd|패널 (금),panelgold|패널 (녹),panelgreen|패널 (보라),panelpurple|패널 (적),panelred|패널 (은),panelsilver|액자 (클래식),nouveau2|액자 (아르누보),nouveau|소울,souls|맹세 (흑금),oath|독약 라벨,poison|유리,glass|별빛 (남색),starlight|별빛 (금색),gilded|숲 녹색,forest|숲 붉은색,crimson|고딕 쪽지,gothic|원정대,expedition|러브 하트,loveheart}' },
    { label: '카드·설정 모양 보기', cmd: '@ext:open https://claude.ai/artifact/UeBJj6FXKGuiK2YoSibCtv' },
    { label: '주문 연출 메뉴', cmd: '!연출' },
    { label: '소환수 맡기기 (선택 토큰)', cmd: '!소환' },
    { label: '동행 등록·목록 (선택 토큰)', cmd: '!동행' },
    { label: '애니메이션 효과', cmd: '!효과' },
    { label: '상태 고리 (표식 애니메이션)', cmd: '!표식' },
    { label: '범위 템플릿 켜기/끄기', cmd: '!범위 템플릿' },
    { label: '몸집별 효과 크기', cmd: '!효과 몸집 ?{몸집|아주 작음,tiny|작음·중간,medium|큼,large|거대,huge|초대형,gargantuan} ?{크기 ft|7}' },
    { label: '임시 HP 주기', cmd: '!임시HP ?{임시 HP (선택한 토큰, 0이면 없애기)|5}' },
    { label: '임시 HP 바 고르기', cmd: '!pc tempbar ?{임시 HP를 둘 토큰 바|안 씀,0|1번,1|2번,2|3번,3}' },
    { label: '적 HP 공개 방식', cmd: '!pc npchp ?{적 HP를 어떻게 보여 줄까요?|바 + 누적 피해,bar|바만,baronly|누적 피해만,dmg|숨김,hide|숫자 그대로,show}' },
    { label: 'HP 색·말 단계 수', cmd: '!pc hpsteps ?{몇 단계로 나눌까요?|5|3|4|6|8|10}' },
    { label: 'HP 상태 말 바꾸기', cmd: '!pc hpwords ?{건강한 쪽부터 쉼표로 (개수 = 단계 수) 예: 멀쩡함, 다침, 피투성이, 빈사}' },
    { label: '무기·주문 아이콘 켜기/끄기', cmd: '!pc wicon ?{무기·주문 아이콘|켜기,on|끄기,off}' },
    { label: '시트 주문 목록 읽기', cmd: '!pc spells' },
    { label: '주문 아이콘 짝 맞추기', cmd: '@ext:open https://arcadelt123-hash.github.io/Phandelverdelver/spell_icons.html' }
  ] },
  { name: '설정', buttons: [
    { label: 'Mod 메뉴·설정', cmd: '!pc' },
    { label: '함정·비밀', cmd: '!함정' },
    { label: '쉬는 시간 알림음', cmd: '!쉬는시간' },
    { label: '샘플 카드', cmd: '!pc test' },
    { label: '원본 귓속말 숨기기 켜기/끄기', cmd: '@ext:hideraw' }
  ] }
];
