const DEF = [
  { match: '판델버', room: 'r_Phandelverdelver', url: 'https://arcadelt123-hash.github.io/Phandelverdelver/' },
  { match: '평일', room: 'r_TUEdragonheist', url: 'https://arcadelt123-hash.github.io/TUEdragonheist/' },
  { match: '드래곤', room: 'r_Dragonheisthesit', url: 'https://arcadelt123-hash.github.io/Dragonheisthesit/' }
];
const $ = id => document.getElementById(id);
chrome.storage.sync.get('sites', s => { const L = Array.isArray(s.sites) && s.sites.length ? s.sites.slice() : []; DEF.forEach(d => { if (!L.some(x => (x.url || '').replace(/\/$/, '') === d.url.replace(/\/$/, ''))) L.push(d); }); $('t').value = L.map(x => [x.match, x.room, x.url].concat(x.exec ? [x.exec] : []).join(' | ')).join('\n'); });
chrome.storage.sync.get('auto', s => { $('a').checked = !!s.auto; });
$('a').onchange = () => chrome.storage.sync.set({ auto: $('a').checked });
$('s').onclick = () => {
  const L = $('t').value.split('\n').map(l => l.split('|').map(x => x.trim())).filter(p => p[0] && p[1]).map(p => ({ match: p[0], room: p[1], url: p[2] || '', exec: p[3] || '' }));
  chrome.storage.sync.set({ sites: L }, () => { $('m').textContent = '저장했어요'; setTimeout(() => { $('m').textContent = ''; }, 1500); });
};

// 세션 채팅 → 저널 세션 로그 (Roll20 게임 탭이 열려 있어야 해요)
document.getElementById('lg').onclick = () => {
  const b = document.getElementById('lg'), m = document.getElementById('lgm');
  b.disabled = true; m.textContent = 'Roll20 채팅 기록 읽는 중… (몇 초 걸려요)';
  chrome.runtime.sendMessage({ type: 'archiveSave' }, r => {
    b.disabled = false;
    if (chrome.runtime.lastError || !r || !r.ok) { m.textContent = '실패: ' + ((r && r.error) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || '알 수 없는 오류'); return; }
    m.textContent = '저널을 열었어요 · 채팅 ' + r.n + '개. 회차 이름만 확인해 주세요.';
  });
};

// GM 패널 보이는 방식
document.getElementById('pw').onclick = () => chrome.runtime.sendMessage({ type: 'panelWin' });
document.getElementById('pf').onclick = () => chrome.runtime.sendMessage({ type: 'panelFloat' });
document.getElementById('po').onclick = () => chrome.storage.local.set({ panelMode: 'off' });

// PC 시트 → 저널 (0.7.6)
const gShow = () => chrome.storage.sync.get('ghToken', r => { $('gs').textContent = r.ghToken ? '· 토큰 저장됨' : '· 토큰 없음'; });
gShow();
$('gsv').onclick = () => { const v = $('gt').value.trim(); if (!v) return; chrome.storage.sync.set({ ghToken: v }, () => { $('gt').value = ''; gShow(); }); };
$('gdel').onclick = () => chrome.storage.local.remove('ghToken', () => chrome.storage.sync.remove('ghToken', gShow));
chrome.storage.local.get('ghToken', r => { if (r.ghToken) chrome.storage.sync.set({ ghToken: r.ghToken }, () => chrome.storage.local.remove('ghToken', gShow)); });
$('gx').onclick = () => { $('gxm').textContent = '게임 화면에서 진행돼요…'; chrome.runtime.sendMessage({ type: 'r20cmd', cmd: '@ext:sheets' }, r => { $('gxm').textContent = r && r.ok ? '게임 화면을 봐 주세요' : ((r && r.error) || '실패'); }); };
