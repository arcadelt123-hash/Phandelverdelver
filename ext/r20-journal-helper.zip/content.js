// Roll20 저널 도우미 - Roll20 화면에서 도는 부분
(function () {
  if (window.__r20jh) return; window.__r20jh = 1;
  const CHECKS = [
    ['채팅 입력칸', '#textchat-input textarea'],
    ['채팅 기록', '#textchat'],
    ['채팅 메시지 목록', '#textchat .content, #textchat .message, #textchat'],
    ['맵 영역', '#playerzone, #editor-wrapper, #editor']
  ];
  let bannerBox = null, miss = {}, alerted = '', t0 = Date.now(), seenOnce = {};
  function box() {
    if (bannerBox && document.body.contains(bannerBox)) return bannerBox;
    bannerBox = document.createElement('div');
    bannerBox.id = 'r20jh-box';
    bannerBox.style.cssText = 'position:fixed;top:12px;right:470px;z-index:2147483000;display:flex;flex-direction:column;gap:8px;max-width:340px;font:13px/1.4 sans-serif';
    document.body.appendChild(bannerBox); return bannerBox;
  }
  function banner(html, color, ms, link) {
    const d = document.createElement('div');
    d.style.cssText = 'background:#fbf3df;color:#3b2a14;border:2px solid ' + color + ';border-radius:10px;padding:8px 12px;box-shadow:0 4px 14px rgba(0,0,0,.35);cursor:default';
    d.innerHTML = html;
    if (link) { const a = document.createElement('a'); a.href = link; a.target = '_blank'; a.textContent = '저널 열기'; a.style.cssText = 'display:inline-block;margin-top:4px;color:#7a4a14;font-weight:700'; d.appendChild(a); }
    const x = document.createElement('span'); x.textContent = ' ×'; x.style.cssText = 'float:right;cursor:pointer;font-weight:700'; x.onclick = () => d.remove(); d.prepend(x);
    box().appendChild(d); if (ms) setTimeout(() => d.remove(), ms); return d;
  }
  function beep() { try { const c = new (window.AudioContext || window.webkitAudioContext)(), o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = 880; g.gain.value = .08; o.connect(g); g.connect(c.destination); o.start(); setTimeout(() => { o.frequency.value = 1320; }, 140); setTimeout(() => { o.stop(); c.close(); }, 320); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

  // 1) Roll20 구조 점검: 한 번이라도 보였던 요소가 30초 넘게 없어지거나, 2분 넘게 한 번도 안 보이면 알림
  function health() {
    const bad = [];
    CHECKS.forEach(([name, sel]) => {
      const ok = !!document.querySelector(sel);
      if (ok) { seenOnce[name] = true; miss[name] = 0; return; }
      miss[name] = (miss[name] || 0) + 1;
      const limit = seenOnce[name] ? 3 : 12;   // 10초마다 점검: 3회=30초, 12회=2분
      if (miss[name] >= limit) bad.push(name);
    });
    const key = bad.join(',');
    if (key && key !== alerted) {
      alerted = key;
      banner('<b>Roll20 화면 구조가 바뀐 것 같아요</b><br>찾지 못한 곳: ' + esc(bad.join(', ')) + '<br><small>연동 기능이 멈췄을 수 있어요.</small>', '#b3261e');
      try { chrome.runtime.sendMessage({ type: 'notify', title: 'Roll20 저널 도우미', message: 'Roll20 화면 구조가 바뀐 것 같아요: ' + bad.join(', '), badge: '!' }); } catch (e) {}
    } else if (!key && alerted) { alerted = ''; try { chrome.runtime.sendMessage({ type: 'badge', text: '' }); } catch (e) {} }
  }
  setInterval(health, 10000);

  // 2) 상점 판매 요청 / 상점 입장
  let liveKey = '', liveInit = false, notkShown = false, notkBox = null, errShown = false;
  function poll() {
    try {
      chrome.runtime.sendMessage({ type: 'poll', title: document.title }, res => {
        if (chrome.runtime.lastError || !res) return;
        if (res.ok && res.notk) { if (!notkShown || !notkBox || !notkBox.isConnected) { notkShown = true; notkBox = banner('<b>판매 요청·상점 입장 알림이 꺼져 있어요</b><br>이 브라우저에서 저널(' + esc(res.match) + ')에 <b>GM으로 로그인한 탭</b>을 한 번 열어 주세요. 그 뒤로는 자동이에요.', '#b8893a', 0, res.url); } return; }
        // 저널이 연결되면 안내를 저절로 닫아요
        if (notkBox) { notkBox.remove(); notkBox = null; } notkShown = false;
        if (!res.ok) { if (res.error && !errShown) { errShown = true; banner('<b>상점 알림 연결이 잠깐 안 돼요</b><br><small>' + esc(String(res.error).slice(0, 120)) + ' · 저절로 다시 시도해요</small>', '#b3261e', 15000); } return; }
        errShown = false;
        if (res.none) return;
        if (!res.out) return;
        const o = res.out;
        (o.sells || []).forEach(s => { beep(); banner('<b>판매 요청</b> · ' + esc(s.n) + '<br>' + esc(s.t), '#b8893a', 0, o.url); try { chrome.runtime.sendMessage({ type: 'notify', title: '판매 요청', message: (s.n ? s.n + ': ' : '') + s.t }); } catch (e) {} });
        const k = (o.live || []).map(x => x.n + '|' + x.s + '|' + x.w).sort().join(';');
        if (k !== liveKey || !liveInit) { const prev = new Set(liveKey.split(';')); (o.live || []).forEach(x => { const id = x.n + '|' + x.s + '|' + x.w; if (liveInit && !prev.has(id)) banner('<b>' + esc(x.n) + '</b>님이 ' + esc(x.s || '상점') + '에 들어왔어요 (' + (x.w === 'shared' ? '공용 가방' : esc(x.pc || 'PC')) + ')', '#6b8e5a', 8000, o.url); }); liveKey = k; liveInit = true; }
      });
    } catch (e) {}
  }
  setInterval(poll, 6000); setTimeout(poll, 3000);

  // 3) 저널에서 온 거래 명령을 채팅에 입력 (자동 반영) + 새로 산 아이템 복사 패널
  let q = [], busy = false, sentItems = {}, siLoaded = false;
  try { chrome.storage.local.get('sentItems', r => { sentItems = Object.assign({}, r && r.sentItems || {}, sentItems); siLoaded = true; }); } catch (e) { siLoaded = true; }
  function siSave() { try { const ks = Object.keys(sentItems); if (ks.length > 300) ks.slice(0, ks.length - 300).forEach(k => delete sentItems[k]); chrome.storage.local.set({ sentItems }); } catch (e) {} }
  function sendChat(cmd) {
    const ta = document.querySelector('#textchat-input textarea'); if (!ta || ta.value.trim()) return false;
    try {
      Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(ta, cmd); ta.dispatchEvent(new Event('input', { bubbles: true }));
      ['keydown', 'keypress', 'keyup'].forEach(t => { const e = new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }); try { Object.defineProperty(e, 'keyCode', { get: () => 13 }); Object.defineProperty(e, 'which', { get: () => 13 }); } catch (x) {} ta.dispatchEvent(e); });
    } catch (e) { return false; }
    setTimeout(() => { const t2 = document.querySelector('#textchat-input textarea'); if (t2 && t2.value === cmd) banner('<b>자동 입력은 했는데 Enter가 안 먹었어요</b><br>입력칸에 명령이 들어가 있어요. Enter를 눌러 주세요.<br><small>Roll20 화면이 바뀐 것일 수 있어요.</small>', '#b3261e', 20000); }, 1500);
    return true;
  }
  function itemsOf(cmd) {
    try { const o = JSON.parse(decodeURIComponent(cmd.replace(/^!상점반영\s+/, ''))), E = o.E || {}, out = [];
      (o.pcs || []).forEach(p => (p.L || []).forEach(l => { const t = l.slice(l.indexOf('|') + 1), m = t.match(/·\s*구매\s*:\s*(.+?)(?:\s+\([^()]*\))?\s*$/); if (!m) return; let nm = m[1], n = 1; const nn = nm.match(/^(.*\S)\s*×\s*(\d+)$/); if (nn) { nm = nn[1]; n = +nn[2]; } const k = p.n + '|' + l; if (sentItems[k]) return; out.push({ k, pc: p.n, ko: nm, en: E[nm] || '', n }); }));
      return out; } catch (e) { return []; }
  }
  function itemPanel(list) {
    if (!list.length) return; const d = banner('<b>새로 산 아이템</b> <small>(시트에 추가할 것)</small>', '#2e7d32', 0); const body = document.createElement('div'); body.style.marginTop = '4px';
    list.forEach(i => { const r = document.createElement('div'); r.style.cssText = 'display:flex;gap:6px;align-items:center;margin-top:3px'; const sp = document.createElement('span'); sp.textContent = i.pc + ' · ' + (i.en || i.ko) + (i.n > 1 ? ' ×' + i.n : ''); sp.style.flex = '1';
      const b = document.createElement('button'); b.textContent = '이름 복사'; b.style.cssText = 'cursor:pointer;padding:1px 8px'; b.onclick = () => { try { navigator.clipboard.writeText(i.en || i.ko); b.textContent = '복사됨'; } catch (e) { b.textContent = '실패'; } };
      r.appendChild(sp); r.appendChild(b); body.appendChild(r); sentItems[i.k] = 1; });
    d.appendChild(body); siSave();
  }
  function drain() {
    if (busy || !q.length || !siLoaded) return; busy = true; const it = q[0];
    if (Date.now() - it.t > 60000) { q.shift(); busy = false; banner('<b>저널 거래를 Roll20에 못 넣었어요</b><br>채팅 입력칸이 계속 차 있었어요. 저널의 "소지금·거래 복사"로 직접 반영해 주세요.', '#b3261e', 20000); return; }
    if (sendChat(it.cmd)) { q.shift(); itemPanel(itemsOf(it.cmd)); }
    busy = false;
  }
  try { chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'chatCmd' && /^!상점반영 /.test(m.cmd)) { q = q.filter(x => x.cmd !== m.cmd); q.push({ cmd: m.cmd, t: Date.now() }); drain(); } }); } catch (e) {}
  setInterval(drain, 2000);

  // 4) Roll20 → 저널 (0.4)
  //  ① 채팅의 '저널에 반영' 링크(#r20bag=…)를 자동으로 저널 가방에 보내요 (GM 귓속말로만 와요)
  //  ② !세션정리 카드가 보이면 '저널에 저장' 창 → 누르면 Roll20 채팅 기록(아카이브)에서 이번 세션 부분만 잘라 저널 세션 로그로
  //     (세션 중에는 아무것도 모으지 않아요. 나중에 저장하려면 확장 아이콘 → '이번 세션 채팅을 저널에 저장')
  try { chrome.storage.local.remove('cap_' + location.pathname); } catch (e) {}   // 0.4의 실시간 기록 흔적 정리
  let endShown = '';
  function saveLogNow(btn, box) {
    if (btn) { btn.disabled = true; btn.textContent = '채팅 기록 읽는 중…'; }
    try { chrome.runtime.sendMessage({ type: 'archiveSave' }, r => {
      if (chrome.runtime.lastError || !r || !r.ok) { if (btn) { btn.disabled = false; btn.textContent = '다시 시도'; } banner('<b>저널에 저장하지 못했어요</b><br>' + esc((r && r.error) || '확장을 다시 불러온 뒤 시도해 주세요'), '#b3261e', 20000); return; }
      if (box) box.remove(); banner('<b>저널을 열었어요</b><br>채팅 ' + r.n + '개 · 회차 이름만 확인해 주세요.', '#2e7d32', 8000);
    }); } catch (e) {}
  }
  function endBanner() {
    const d = banner('<b>세션이 끝났어요</b><br>이번 세션 채팅을 저널 세션 로그로 저장할까요?<br><small>나중에 해도 돼요 (확장 아이콘 → 저장). 채팅 기록을 지우기 전에만 해 주세요.</small>', '#2e7d32', 0);
    const row = document.createElement('div'); row.style.cssText = 'margin-top:6px;display:flex;gap:6px';
    const ok = document.createElement('button'); ok.textContent = '저널에 저장'; ok.style.cssText = 'cursor:pointer;padding:2px 10px;font-weight:700';
    const no = document.createElement('button'); no.textContent = '나중에'; no.style.cssText = 'cursor:pointer;padding:2px 10px';
    ok.onclick = () => saveLogNow(ok, d); no.onclick = () => d.remove();
    row.appendChild(ok); row.appendChild(no); d.appendChild(row);
  }
  const startT = Date.now();
  // ③ (0.6.8) 원본 귓속말 숨기기 — 시트 굴림(GM 귓속말)을 Mod가 카드로 다시 그리면, GM 화면에서 원본 귓속말을 감춰요.
  //    짝이 되는 카드(같은 주문·공격 이름)가 3분 안에 안 오면(비밀 굴림 등) 그대로 둬요. 이 브라우저 화면에서만 감추는 것이고 기록은 지우지 않아요.
  let hideRaw = true; const rawQ = [];
  try { chrome.storage.local.get('hideRaw', r => { if (r && r.hideRaw === false) hideRaw = false; }); chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.hideRaw) { hideRaw = ch.hideRaw.newValue !== false; document.querySelectorAll('#textchat .message[data-r20jh-raw]').forEach(m => { m.style.display = hideRaw ? 'none' : ''; }); } }); } catch (e) {}
  const nrm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  function rawPair(el) {
    const now = Date.now();
    while (rawQ.length && now - rawQ[0].t > 180000) rawQ.shift();
    if (el.classList.contains('whisper') && el.querySelector('rolltemplate, .sheet-rolltemplate')) {
      const ti = nrm((el.querySelector('.header__title') || {}).textContent).replace(/\s+(damage|healing|heal)$/, ''); if (ti) rawQ.push({ el, t: now, ti });
      return;
    }
    if (!rawQ.length || el.classList.contains('whisper') || el.querySelector('rolltemplate') || !el.querySelector('div[style*="-4px"]')) return;
    const tx = nrm(el.textContent);
    for (let i = rawQ.length - 1; i >= 0; i--) {
      const q = rawQ[i]; if (!tx.includes(q.ti)) continue;
      q.el.setAttribute('data-r20jh-raw', '1'); if (hideRaw) q.el.style.display = 'none'; rawQ.splice(i, 1); break;
    }
  }
  function seeMsg(el) {
    if (!el || !el.classList || !el.classList.contains('message')) return;
    const id = el.getAttribute('data-messageid'); if (!id) return;
    try { rawPair(el); } catch (e) {}
    const txt = el.textContent || '';
    // ① 가방 링크
    el.querySelectorAll('a[href*="#r20bag="]').forEach(a => {
      if (a.dataset.r20jh) return; a.dataset.r20jh = '1';
      const href = a.getAttribute('href') || '', m = href.match(/#r20bag=(.+)$/); if (!m) return;
      let data = null; try { data = JSON.parse(decodeURIComponent(m[1])); } catch (e) { return; }
      try { chrome.runtime.sendMessage({ type: 'bag', href, id: data && data.id, data }, r => { if (chrome.runtime.lastError || !r) return; if (r.sent || r.dup) { a.textContent = r.dup ? '반영됨' : '저널로 보냄'; a.style.opacity = '.6'; } }); } catch (e) {}
    });
    // ② 세션 시작/끝 표시 (페이지를 막 열었을 때 다시 그려지는 예전 메시지는 무시)
    if (Date.now() - startT < 8000) return;
    if (/세션 기록 시작 —/.test(txt)) banner('<b>세션 시작 확인</b><br><small>!세션정리 하면 이번 세션 채팅을 저널에 저장할 수 있어요.</small>', '#2e7d32', 6000);
    if (endShown !== id && /세션 마무리/.test(txt) && [...el.querySelectorAll('div')].some(d => !d.children.length && d.textContent.trim() === '세션 마무리')) { endShown = id; endBanner(); }
  }
  let chatObs = null;
  function hookChat() {
    const root = document.querySelector('#textchat .content') || document.querySelector('#textchat');
    if (!root || (chatObs && chatObs.root === root)) return;
    if (chatObs) chatObs.disconnect();
    chatObs = new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType !== 1) return; if (n.classList.contains('message')) seeMsg(n); else n.querySelectorAll && n.querySelectorAll('.message[data-messageid]').forEach(seeMsg); })));
    chatObs.root = root; chatObs.observe(root, { childList: true, subtree: true });
  }
  setInterval(hookChat, 3000); setTimeout(hookChat, 1500);

  // 5) GM 패널 (0.6) — 버튼으로 Mod 명령 보내기. 게임 화면 위에 띄우거나(끌어서 옮기기·크기 조절·접기) 따로 창으로.
  function sendChatLines(lines, done) {
    const box = document.querySelector('#textchat-input'), ta = box && box.querySelector('textarea'), btn = box && box.querySelector('button');
    if (!ta || !btn) return done({ ok: false, error: 'Roll20 채팅 입력칸을 못 찾았어요.' });
    const draft = ta.value; let i = 0;
    (function next() {
      if (i >= lines.length) { ta.value = draft; return done({ ok: true }); }
      ta.value = lines[i++]; ta.dispatchEvent(new Event('input', { bubbles: true })); btn.click();
      setTimeout(next, 400);
    })();
  }
  chrome.runtime.onMessage.addListener((m, s, send) => {
    if (m && m.type === 'sendChat') {
      let lines = Array.isArray(m.lines) ? m.lines : [];
      if (lines.some(l => /^@ext:sheets/.test(l))) { sxExport(null); lines = lines.filter(l => !/^@ext:sheets/.test(l)); if (!lines.length) { send({ ok: true }); return true; } }
      if (lines.some(l => /^@ext:(maps|float|tools)/.test(l))) { lines.forEach(l => { if (/^@ext:maps\s*$/.test(l)) window.postMessage({ r20h: 'maps' }, '*'); const fm = l.match(/^@ext:float\s+(\w+)/); if (fm) window.postMessage({ r20h: 'float', which: fm[1] }, '*'); const tm = l.match(/^@ext:tools\s*(\w*)/); if (tm) window.postMessage({ r20h: 'tools', which: tm[1] || '' }, '*'); }); lines = lines.filter(l => !/^@ext:/.test(l)); if (!lines.length) { send({ ok: true }); return true; } }   // 0.7.2: 맵 목록은 채팅 대신 화면에서
      sendChatLines(lines, send); return true; }
  });
  // 0.7.3: 맵·장면 창 ↔ 게임 화면(MAIN의 hd.js) 다리
  const pend = {}; let reqN = 0;
  window.addEventListener('message', e => { if (e.source !== window || !e.data) return;
    if (e.data.r20h === 'res' && pend[e.data.id]) { const f = pend[e.data.id]; delete pend[e.data.id]; f(e.data); }
    if (e.data.r20h === 'mapswin') { try { chrome.runtime.sendMessage({ type: 'mapsWin' }); } catch (er) {} } });
  chrome.runtime.onMessage.addListener((m, s, send) => {
    if (!m || m.type !== 'mapsReq') return;
    const id = 'q' + (++reqN) + Date.now(); const t = setTimeout(() => { delete pend[id]; send({ ok: false, error: '게임 화면이 응답하지 않아요' }); }, 5000);
    pend[id] = r => { clearTimeout(t); send(r.error ? { ok: false, error: r.error } : { ok: true, data: r.data }); };
    window.postMessage({ r20h: 'req', id, op: m.op, args: m.args }, '*'); return true; });
  const here = () => { try { chrome.runtime.sendMessage({ type: 'r20here' }); } catch (e) {} };
  window.addEventListener('focus', here); here();

  let pWrap = null, pState = { mode: 'mini', x: null, y: 70, w: 360, h: 430 };
  const clampPos = () => { pState.x = Math.max(0, Math.min(window.innerWidth - 120, pState.x == null ? window.innerWidth - pState.w - 330 : pState.x)); pState.y = Math.max(0, Math.min(window.innerHeight - 40, pState.y)); };
  function pSave() { try { chrome.storage.local.set({ panelMode: pState.mode, panelPos: { x: pState.x, y: pState.y, w: pState.w, h: pState.h } }); } catch (e) {} }
  function pRender() {
    if (pWrap) { pWrap.remove(); pWrap = null; }
    if (pState.mode === 'off' || pState.mode === 'win') return;   // 따로 창으로 띄웠으면 게임 화면엔 아무것도 안 남겨요 (창을 닫으면 작은 버튼이 돌아와요)
    clampPos();
    const w = document.createElement('div'); pWrap = w;
    const open = pState.mode === 'open';
    w.style.cssText = 'position:fixed;z-index:2147483000;left:' + pState.x + 'px;top:' + pState.y + 'px;' + (open
      ? 'box-sizing:border-box;width:' + pState.w + 'px;height:' + pState.h + 'px;resize:both;overflow:hidden;min-width:220px;min-height:160px;display:flex;flex-direction:column;border:2px solid #c9a045;border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.45);background:#ead9b2;'
      : 'border:2px solid #c9a045;border-radius:14px;box-shadow:0 2px 8px rgba(0,0,0,.4);background:#7a1f1f;');
    const bar = document.createElement('div');
    bar.style.cssText = 'display:flex;align-items:center;gap:6px;padding:3px 8px;background:#7a1f1f;color:#f8e9c4;font:bold 12px sans-serif;cursor:move;user-select:none;border-radius:' + (open ? '6px 6px 0 0' : '12px');
    const title = document.createElement('span'); title.textContent = pState.mode === 'win' ? 'GM 패널 (창)' : 'GM 패널'; title.style.flex = '1';
    bar.appendChild(title);
    const mk = (t, tip, fn) => { const b = document.createElement('button'); b.textContent = t; b.title = tip; b.style.cssText = 'border:1px solid #c9a045;border-radius:3px;background:#f3e6c4;color:#2b1d0e;padding:0 6px;font:11px sans-serif;cursor:pointer'; b.onmousedown = e => e.stopPropagation(); b.onclick = e => { e.stopPropagation(); fn(); }; bar.appendChild(b); };
    if (open) { mk('창으로', '따로 창으로 띄우기', () => chrome.runtime.sendMessage({ type: 'panelWin' })); mk('접기', '작은 버튼으로 접기', () => { pState.mode = 'mini'; pSave(); pRender(); }); }
    else if (pState.mode === 'win') mk('창 보기', '패널 창을 앞으로', () => chrome.runtime.sendMessage({ type: 'panelWin' }));
    else { title.style.cursor = 'pointer'; title.onclick = () => { pState.mode = 'open'; pSave(); pRender(); }; mk('창으로', '따로 창으로 띄우기', () => chrome.runtime.sendMessage({ type: 'panelWin' })); }
    w.appendChild(bar);
    if (open) { const f = document.createElement('iframe'); f.src = chrome.runtime.getURL('panel.html'); f.style.cssText = 'flex:1;border:0;width:100%;background:#ead9b2'; w.appendChild(f); }
    // 끌어서 옮기기
    bar.addEventListener('mousedown', e => {
      const sx = e.clientX, sy = e.clientY, ox = pState.x, oy = pState.y, moved = { v: false };
      const cover = document.createElement('div'); cover.style.cssText = 'position:fixed;inset:0;z-index:2147483001;cursor:move'; document.body.appendChild(cover);
      const mv = ev => { moved.v = true; pState.x = ox + ev.clientX - sx; pState.y = oy + ev.clientY - sy; clampPos(); w.style.left = pState.x + 'px'; w.style.top = pState.y + 'px'; };
      const up = () => { cover.remove(); document.removeEventListener('mousemove', mv); document.removeEventListener('mouseup', up); if (moved.v) pSave(); };
      document.addEventListener('mousemove', mv); document.addEventListener('mouseup', up); e.preventDefault();
    });
    // 크기 조절 기억
    if (open && window.ResizeObserver) new ResizeObserver(() => { const r = w.getBoundingClientRect(); if (Math.abs(r.width - pState.w) > 2 || Math.abs(r.height - pState.h) > 2) { pState.w = Math.round(r.width); pState.h = Math.round(r.height); clearTimeout(w._t); w._t = setTimeout(pSave, 400); } }).observe(w);
    document.body.appendChild(w);
  }
  try {
    chrome.storage.local.get(['panelMode', 'panelPos'], r => { if (r.panelMode) pState.mode = r.panelMode; if (r.panelPos) Object.assign(pState, r.panelPos); pRender(); });
    chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.panelMode && ch.panelMode.newValue && ch.panelMode.newValue !== pState.mode) { pState.mode = ch.panelMode.newValue; pRender(); } });
  } catch (e) {}

  // 6) PC 시트 → 저널 (0.7.6): 레벨이 바뀐 PC가 있으면 알려 주고, [시트 내보내기]로 저널(GitHub)에 저장해요
  let sxBox = null, sxBusy = false;
  function sxInit() {
    try { chrome.runtime.sendMessage({ type: 'sxSite', title: document.title }, r => {
      if (chrome.runtime.lastError || !r || !r.ok || !r.base) return;
      window.postMessage({ r20h: 'sxInit', base: r.base, skip: r.skip || [] }, '*');
    }); } catch (e) {}
  }
  function sxExport(btn) {
    if (sxBusy) return; sxBusy = true;
    if (btn) { btn.disabled = true; btn.textContent = '시트 읽는 중…'; }
    const prog = btn ? null : banner('<b>시트 내보내는 중…</b>', '#b8893a', 0);
    const fail = t => { sxBusy = false; if (prog) prog.remove(); if (btn) { btn.disabled = false; btn.textContent = '다시 시도'; } banner('<b>시트를 내보내지 못했어요</b><br>' + esc(t), '#b3261e', 20000); };
    const id = 'sx' + (++reqN) + Date.now();
    const t = setTimeout(() => { delete pend[id]; fail('게임 화면이 응답하지 않아요. 새로 고친 뒤 다시 해 주세요.'); }, 120000);
    pend[id] = res => {
      clearTimeout(t);
      if (res.error) return fail(res.error);
      if (btn) btn.textContent = 'GitHub에 저장 중…';
      try { chrome.runtime.sendMessage({ type: 'sxExport', title: document.title, data: res.data }, r => {
        sxBusy = false; if (prog) prog.remove();
        if (chrome.runtime.lastError || !r || !r.ok) return fail((r && r.error) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || '알 수 없는 오류');
        if (sxBox) { sxBox.remove(); sxBox = null; }
        banner('<b>시트를 저널에 저장했어요</b><br>PC ' + r.n + '명' + (r.nc ? ' · 동행 ' + r.nc : '') + (r.changes.length ? '<br>' + r.changes.map(esc).join('<br>') : ' · 레벨 변화 없음') + '<br><small>1~2분 뒤 저널에 반영돼요.</small>', '#2e7d32', 15000, r.url);
      }); } catch (e) { fail(String(e.message || e)); }
    };
    try { chrome.runtime.sendMessage({ type: 'sxNames', title: document.title }, r => { void chrome.runtime.lastError; window.postMessage({ r20h: 'sxReq', id, names: (r && r.names) || [] }, '*'); }); }
    catch (e) { window.postMessage({ r20h: 'sxReq', id, names: [] }, '*'); }
  }
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.r20h !== 'sxLvl') return;
    const L = (e.data.list || []).filter(x => !x.isNew);
    if (sxBox) { sxBox.remove(); sxBox = null; }
    if (!L.length) return;
    sxBox = banner('<b>레벨이 바뀐 PC가 있어요</b><br>' + L.map(x => esc(x.n) + ' ' + x.from + ' → ' + x.to).join('<br>') + '<br><small>레벨업을 다 끝냈으면 시트를 저널에 내보내 주세요. 바뀌기 전 시트는 레벨 기록으로 남아요.</small>', '#b8893a', 0);
    const row = document.createElement('div'); row.style.cssText = 'margin-top:6px;display:flex;gap:6px';
    const ok = document.createElement('button'); ok.textContent = '시트 내보내기'; ok.style.cssText = 'cursor:pointer;padding:2px 10px;font-weight:700';
    const no = document.createElement('button'); no.textContent = '나중에'; no.style.cssText = 'cursor:pointer;padding:2px 10px';
    ok.onclick = () => sxExport(ok); no.onclick = () => { sxBox.remove(); sxBox = null; };
    row.appendChild(ok); row.appendChild(no); sxBox.appendChild(row);
  });
  chrome.runtime.onMessage.addListener((m, s, send) => { if (m && m.type === 'sxRun') { sxExport(null); send({ ok: true }); } });
  // 0.7.9: 자동으로 시트를 읽지 않아요 (내보내기 버튼을 누를 때만 읽어요)
})();
