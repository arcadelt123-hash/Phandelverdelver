// Roll20 저널 도우미 — 맵 · 장면 창 (따로 띄운 창). 게임 화면(GM)의 Campaign과 메시지로 주고받아요.
(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const GEAR = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3.3h-4l-.4 2.6a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1a7.4 7.4 0 0 0 1.7 1l.4 2.6h4l.4-2.6a7.4 7.4 0 0 0 1.7-1l2.5 1 2-3.5zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" transform="translate(-1 0)"/></svg>';
  let S = null, tab = 'scenes', q = '', showArch = false, gearOpen = '', renaming = '', armed = '', dragId = '', picking = false, nfOpen = false;
  let form = null;   // 장면 편집 중: { orig, name, page, music, amb, tod, nar }
  const open = (() => { try { return JSON.parse(localStorage.getItem('mapsFold') || '{}'); } catch (e) { return {}; } })();
  const saveFold = () => { try { localStorage.setItem('mapsFold', JSON.stringify(open)); } catch (e) {} };

  function status(t, err) { const s = $('#status'); s.textContent = t || ''; s.className = err ? 'err' : ''; clearTimeout(status.t); if (t) status.t = setTimeout(() => { s.textContent = ''; }, 4000); }
  function req(op, args) { return new Promise(res => chrome.runtime.sendMessage({ type: 'mapsReq', op, args }, r => { if (chrome.runtime.lastError || !r) return res({ ok: false, error: '확장 프로그램과 연결이 끊겼어요' }); res(r); })); }
  function cmd(c) { return new Promise(res => chrome.runtime.sendMessage({ type: 'r20cmd', cmd: c }, r => res(r && r.ok ? r : { ok: false, error: (r && r.error) || 'Roll20 게임 탭을 못 찾았어요' }))); }
  async function act(op, args, okMsg) { const r = await req(op, args); if (!r.ok) return status(r.error || '실패했어요', true); if (okMsg) status(okMsg); setTimeout(load, 400); }

  async function load() {
    if (dragId || (renaming && document.activeElement && document.activeElement.dataset && document.activeElement.dataset.rn)) return;
    const r = await req('state');
    if (!r.ok) { if (!S) $('#main').innerHTML = `<div class="empty">${esc(r.error || 'Roll20 게임 화면을 못 찾았어요')}<br><br>Roll20 게임 화면을 GM으로 열어 두면 여기 맵이 보여요.</div>`; else status(r.error, true); return; }
    S = r.data; document.title = '장면 설정 — ' + (S.game || 'Roll20');
    const ae = document.activeElement; if (ae && $('#main').contains(ae) && /INPUT|TEXTAREA|SELECT/.test(ae.tagName)) return;   // 입력 중이면 화면을 안 바꿔요
    render();
  }

  // ---- 맵 ----
  const pagesV = () => S.pages.filter(p => showArch || !p.ar);
  const sib = path => { const it = []; S.folders.filter(f => f.path === path).forEach(f => it.push({ k: 'f', o: f, id: f.id, pl: f.pl })); pagesV().filter(p => p.path === path).forEach(p => it.push({ k: 'p', o: p, id: p.id, pl: p.pl })); return it.sort((a, b) => a.pl - b.pl); };
  const fLabel = () => { const by = {}; S.folders.forEach(f => { by[f.id] = f; }); return S.folders.map(f => ({ path: f.path + f.id + ',', name: f.path.split(',').filter(Boolean).map(i => by[i] ? by[i].name : '?').concat([f.name]).join(' / ') })).sort((a, b) => a.name.localeCompare(b.name)); };
  const med = t => t.replace(/\/thumb\.(png|jpg|jpeg|webp|gif)/i, '/med.$1');
  const bgOf = p => p && p.thumb ? `background-image:url('${esc(med(p.thumb))}'),url('${esc(p.thumb)}')` : '';
  const pageById = id => S.pages.find(p => p.id === id);
  function card(p) {
    const sp = new Set(S.sp), g = gearOpen === p.id;
    const b = (p.id === S.pl ? '<span class="bg pl">PL 리본</span>' : '') + (sp.has(p.id) ? '<span class="bg sp">따로 간 PL</span>' : '') + (p.id === S.cur ? '<span class="bg me">GM이 보는 중</span>' : '') + (p.ar ? '<span class="bg ar">보관</span>' : '');
    const ed = !g ? '' : renaming === p.id
      ? `<div class="ed" data-stop="1"><input data-rn="${esc(p.id)}" value="${esc(p.name)}"><button data-rnok="${esc(p.id)}">저장</button><button data-rnx="1">취소</button></div>`
      : `<div class="ed" data-stop="1"><select data-mv="${esc(p.id)}"><option value="">폴더 옮기기…</option>${p.path !== ',' ? '<option value=",">(폴더 밖으로)</option>' : ''}${fLabel().filter(f => f.path !== p.path).map(f => `<option value="${esc(f.path)}">${esc(f.name)}</option>`).join('')}</select>` +
        `<button data-ren="${esc(p.id)}">이름 바꾸기</button><button data-ar="${esc(p.id)}">${p.ar ? '꺼내기' : '보관'}</button><button data-mkscene="${esc(p.id)}">이 맵으로 장면 만들기</button></div>`;
    return `<div class="card${p.id === S.cur ? ' cur' : ''}${g ? ' gear' : ''}" draggable="true" data-id="${esc(p.id)}" data-path="${esc(p.path)}" style="${bgOf(p)}" title="${picking ? '이 맵을 장면에 넣어요' : '누르면 GM 화면이 이 맵으로 · 끌어서 순서 바꾸기'}">` +
      `<div class="bgs">${b}</div><div class="nm">${esc(p.name || '이름 없는 맵')}</div>` +
      (picking ? '' : `<div class="tr">${p.id === S.pl ? '' : `<button class="${armed === p.id ? 'arm' : ''}" data-rb="${esc(p.id)}">${armed === p.id ? '한 번 더 누르면 옮겨요' : '리본 ⇨'}</button>`}<button class="gr${g ? ' on' : ''}" data-gear="${esc(p.id)}" title="맵 설정">${GEAR}</button></div>`) + ed + '</div>';
  }
  function mapsHtml() {
    const ql = q.trim().toLowerCase();
    if (ql) { const hit = pagesV().filter(p => p.name.toLowerCase().includes(ql)); return hit.length ? `<div class="grid">${hit.map(card).join('')}</div>` : '<div class="empty">찾는 맵이 없어요</div>'; }
    const sp = new Set(S.sp);
    const level = path => { let out = '', buf = [];
      const flush = () => { if (buf.length) { out += `<div class="grid">${buf.join('')}</div>`; buf = []; } };
      sib(path).forEach(it => {
        if (it.k === 'p') return buf.push(card(it.o));
        flush(); const f = it.o, subp = path + f.id + ',', isO = !!open[f.id];
        const n = pagesV().filter(p => p.path.startsWith(subp)).length, hasPl = pagesV().some(p => p.path.startsWith(subp) && (p.id === S.pl || sp.has(p.id)));
        out += `<div class="fd" draggable="true" data-f="${esc(f.id)}" data-path="${esc(path)}" data-sub="${esc(subp)}"><i>${isO ? '▾' : '▸'}</i><span class="n">${esc(f.name)}${hasPl && !isO ? ' <span class="bg pl">PL</span>' : ''}</span><small>${n}</small></div>` + (isO ? `<div class="in">${level(subp)}</div>` : '');
      });
      flush(); return out; };
    return (picking ? '<div class="hint" style="font-size:13px;color:#f3d38a">장면에 넣을 맵을 누르세요 · <button class="btn" data-pickx="1">그만 고르기</button></div>' : '') + (nfOpen ? '<div style="display:flex;gap:6px;margin:4px 0 8px"><input id="nfname" placeholder="새 폴더 이름" style="flex:1;padding:5px 8px;border-radius:6px;border:1px solid #b8893a;background:#14110f;color:#fff"><button class="btn" data-nfok="1">만들기</button></div>' : '') + (level(',') || '<div class="empty">맵이 없어요</div>');
  }

  // ---- 장면 ----
  const TODS0 = ['새벽', '아침', '정오', '오후', '어스름', '일몰', '저녁', '한밤중', '밤의 끄트머리', '어둠달', '밤'];
  const tods = () => (S.scenes && S.scenes.tods) || TODS0;
  const scenes = () => (S.scenes && S.scenes.scenes) || {};
  const jbName = id => { const f = (S.jb || []).find(x => x.id === id); return f ? f.n : ''; };
  const musicTxt = v => v === '=' || !v ? '음악 그대로' : v === '-' ? '음악 끄기' : (jbName(v) || '재생목록');
  function scenesHtml() {
    if (!S.scenes) return '<div class="empty">장면 목록을 아직 못 받았어요. Mod가 최신이면 몇 초 뒤 보여요.</div>' + formHtml();
    const ql = q.trim().toLowerCase();
    const names = Object.keys(scenes()).filter(n => !ql || n.toLowerCase().includes(ql));
    const cards = names.map(n => { const sc = scenes()[n], p = pageById(sc.page), t = tods()[sc.tod];
      return `<div class="card" data-scene="${esc(n)}" style="${bgOf(p)}"><div class="nm">${esc(n)}</div>` +
        `<div class="sub2">${p ? esc(p.name) : '맵 이동 안 함'} · ${esc(musicTxt(sc.music))}${sc.amb && sc.amb !== '-' ? ' · 환경음 ' + esc(jbName(sc.amb)) : ''}${t ? ' · ' + esc(t) : ''}</div>` +
        `<div class="tr"><button class="${armed === 'run:' + n ? 'arm' : ''}" data-run="${esc(n)}">${armed === 'run:' + n ? '한 번 더 = 실행' : '실행'}</button><button data-edit="${esc(n)}">편집</button><button class="${armed === 'del:' + n ? 'arm' : ''}" data-del="${esc(n)}">${armed === 'del:' + n ? '한 번 더 = 삭제' : '삭제'}</button></div></div>`; }).join('');
    return `<div class="scwrap"><div>${cards ? `<div class="grid">${cards}</div>` : '<div class="empty">장면이 없어요. 오른쪽에서 새로 만들어 보세요.</div>'}<div class="hint">실행 = 플레이어 맵 이동 + 음악 + 환경음 + 시간대 + 묘사 (Mod의 !장면과 같아요)</div></div>${formHtml()}</div>`;
  }
  function newForm(page) { form = { orig: '', name: '', page: page || '-', music: '=', amb: '-', tod: -1, nar: '' }; }
  function formHtml() {
    if (!form) newForm();
    const p = pageById(form.page), jb = S.jb || [];
    const amb = jb.slice().sort((a, b) => (/^분위기/.test(b.n) ? 1 : 0) - (/^분위기/.test(a.n) ? 1 : 0));
    const opt = (v, t, cur) => `<option value="${esc(v)}"${String(cur) === String(v) ? ' selected' : ''}>${esc(t)}</option>`;
    return `<div class="form"><h2>${form.orig ? '장면 편집 — ' + esc(form.orig) : '새 장면'}</h2>` +
      `<label>장면 이름</label><input data-f="name" value="${esc(form.name)}" placeholder="예: 트롤스컬 저택 — 밤">` +
      `<label>맵</label><select data-f="page">${opt('-', '맵 이동 안 함', form.page)}${pagesV().slice().sort((a, b) => a.name.localeCompare(b.name)).map(x => opt(x.id, x.name || '이름 없는 맵', form.page)).join('')}</select>` +
      `<div class="prev" style="${bgOf(p)}"><span>${p ? esc(p.name) : ''}</span></div><button class="btn" data-pick="1" style="margin-top:6px">맵 탭에서 그림 보고 고르기</button>` +
      `<label>음악 재생목록</label><select data-f="music">${opt('=', '그대로 두기', form.music)}${opt('-', '끄기', form.music)}${jb.map(x => opt(x.id, x.n, form.music)).join('')}</select>` +
      `<label>환경음 (목록에서 한 곡 무작위로 함께)</label><select data-f="amb">${opt('-', '없음', form.amb)}${amb.map(x => opt(x.id, x.n, form.amb)).join('')}</select>` +
      `<label>시간대</label><select data-f="tod">${opt(-1, '그대로', form.tod)}${tods().map((t, i) => opt(i, t, form.tod)).join('')}</select>` +
      `<label>묘사 (장면이 열릴 때 채팅에 나와요)</label><textarea data-f="nar">${esc(form.nar)}</textarea>` +
      `<div class="row"><button class="btn" data-save="1">${form.orig ? '고친 내용 저장' : '장면 저장'}</button>${form.orig ? '<button class="btn" data-new="1">새 장면으로</button>' : ''}</div></div>`;
  }
  const clean = s => String(s || '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/[|,{}\[\]()\r\n]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 30);

  function render() {
    if (!S) return;
    document.querySelectorAll('.tab').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    $('#nf').style.display = tab === 'maps' ? '' : 'none'; $('#arch').parentNode.style.display = tab === 'maps' ? '' : 'none';
    const m = $('#main'), st = m.scrollTop;
    m.classList.toggle('picking', picking);
    m.innerHTML = tab === 'maps' ? mapsHtml() : scenesHtml();
    m.scrollTop = st;
  }

  // ---- 이벤트 ----
  document.querySelectorAll('.tab').forEach(b => b.onclick = () => { tab = b.dataset.tab; picking = false; gearOpen = ''; render(); });
  $('#q').oninput = e => { q = e.target.value; render(); };
  $('#arch').onchange = e => { showArch = e.target.checked; render(); };
  $('#nf').onclick = () => { nfOpen = !nfOpen; render(); if (nfOpen) setTimeout(() => $('#nfname') && $('#nfname').focus(), 30); };
  const main = $('#main');
  main.addEventListener('input', e => { const f = e.target.dataset && e.target.dataset.f; if (f && form) form[f] = e.target.value; });
  main.addEventListener('change', async e => {
    const d = e.target.dataset || {};
    if (d.f && form) { form[d.f] = e.target.value; if (d.f === 'page') render(); return; }
    if (d.mv && e.target.value) { const to = e.target.value; gearOpen = ''; const f = to.split(',').filter(Boolean).pop(); if (f) { open[f] = true; saveFold(); } act('between', { id: d.mv, path: to, idx: -1 }, '폴더를 옮겼어요'); }
  });
  main.addEventListener('keydown', e => {
    if (e.key === 'Enter' && e.target.id === 'nfname') mkFolder();
    if (e.key === 'Enter' && e.target.dataset.rn) { const v = e.target.value.trim(), id = e.target.dataset.rn; renaming = ''; if (v) act('rename', { id, name: v }, '이름을 바꿨어요'); }
    if (e.key === 'Escape' && renaming) { renaming = ''; render(); }
  });
  function mkFolder() { const i = $('#nfname'), v = i && i.value.trim(); if (!v) return status('폴더 이름을 적어 주세요', true); nfOpen = false; act('addFolder', { name: v, path: ',' }, '새 폴더를 만들었어요 (맨 아래) · 맵을 끌어다 넣으세요'); }
  function arm(k) { armed = k; render(); clearTimeout(arm.t); arm.t = setTimeout(() => { armed = ''; render(); }, 4000); }
  main.addEventListener('click', async e => {
    const t = e.target, d = (t.closest('button') || {}).dataset || {};
    if (d.nfok) return mkFolder();
    if (d.pickx) { picking = false; tab = 'scenes'; return render(); }
    if (d.pick) { picking = true; tab = 'maps'; return render(); }
    if (d.gear) { gearOpen = gearOpen === d.gear ? '' : d.gear; renaming = ''; return render(); }
    if (d.ren) { renaming = d.ren; render(); const i = main.querySelector('input[data-rn]'); if (i) { i.focus(); i.select(); } return; }
    if (d.rnok) { const i = main.querySelector('input[data-rn]'); renaming = ''; if (i && i.value.trim()) return act('rename', { id: d.rnok, name: i.value.trim() }, '이름을 바꿨어요'); return render(); }
    if (d.rnx) { renaming = ''; return render(); }
    if (d.ar) { const p = pageById(d.ar); gearOpen = ''; return act('archive', { id: d.ar, on: !(p && p.ar) }, p && p.ar ? '꺼냈어요' : '보관했어요 ("보관한 맵도"로 다시 볼 수 있어요)'); }
    if (d.mkscene) { gearOpen = ''; newForm(d.mkscene); const p = pageById(d.mkscene); form.name = p ? clean(p.name) : ''; tab = 'scenes'; return render(); }
    if (d.rb) { if (armed !== d.rb) return arm(d.rb); armed = ''; const p = pageById(d.rb); return act('ribbon', { id: d.rb }, '플레이어를 ' + (p ? p.name : '') + ' 맵으로 옮겼어요'); }
    if (d.run) { if (armed !== 'run:' + d.run) return arm('run:' + d.run); armed = ''; const r = await cmd('!장면 ' + d.run); return status(r.ok ? `'${d.run}' 장면을 실행했어요` : r.error, !r.ok); }
    if (d.del) { if (armed !== 'del:' + d.del) return arm('del:' + d.del); armed = ''; const r = await cmd('!장면 삭제 ' + d.del); status(r.ok ? '삭제했어요' : r.error, !r.ok); return setTimeout(load, 4500); }
    if (d.edit) { const sc = scenes()[d.edit]; if (!sc) return; form = { orig: d.edit, name: d.edit, page: sc.page || '-', music: sc.music || '=', amb: sc.amb || '-', tod: sc.tod == null ? -1 : sc.tod, nar: sc.nar || '' }; return render(); }
    if (d.new) { newForm(); return render(); }
    if (d.save) {
      const name = clean(form.name); if (!name) return status('장면 이름을 적어 주세요', true);
      const lines = [];
      if (form.orig && form.orig !== name) lines.push(`!장면 이름변경 ${form.orig}|${name}`);
      lines.push(`!장면 저장 ${name}|${form.page || '-'}|${form.music || '='}|${form.amb || '-'}|${form.tod}|${String(form.nar || '').replace(/\r?\n/g, ' ')}`);
      const r = await cmd(lines.join('\n')); if (!r.ok) return status(r.error, true);
      status(`'${name}' 장면을 저장했어요 (GM 채팅에 장면 목록이 떠요)`); form.orig = name; form.name = name; return setTimeout(load, 4500);
    }
    if (t.closest('[data-stop]') || t.closest('select,input,textarea')) return;
    const fd = t.closest('.fd'); if (fd) { open[fd.dataset.f] = !open[fd.dataset.f]; saveFold(); return render(); }
    const c = t.closest('.card[data-id]');
    if (c) { if (picking) { form = form || {}; form.page = c.dataset.id; picking = false; tab = 'scenes'; return render(); } return act('go', { id: c.dataset.id }, 'GM 화면을 이 맵으로 옮겼어요'); }
  });
  // 끌어다 놓기
  let over = null; const clr = () => { if (over) over.classList.remove('drop'); over = null; };
  main.addEventListener('dragstart', e => { if (tab !== 'maps' || picking) return e.preventDefault(); const el = e.target.closest('[data-id],[data-f]'); if (!el) return; dragId = el.dataset.id || el.dataset.f; el.classList.add('drag'); try { e.dataTransfer.setData('text/plain', dragId); } catch (er) {} });
  main.addEventListener('dragover', e => { if (!dragId) return; const el = e.target.closest('[data-id],[data-f]'); if (!el) return; e.preventDefault(); if (el !== over) { clr(); over = el; el.classList.add('drop'); } });
  main.addEventListener('drop', e => { e.preventDefault(); const el = e.target.closest('[data-id],[data-f]'), src = dragId; clr(); dragId = ''; if (!src || !el) return load();
    if (el.dataset.sub) { if (el.dataset.f === src || el.dataset.sub.includes(',' + src + ',')) return load(); open[el.dataset.f] = true; saveFold(); return act('between', { id: src, path: el.dataset.sub, idx: -1 }, '폴더로 옮겼어요'); }
    const path = el.dataset.path || ',', list = sib(path), idx = list.findIndex(x => x.id === el.dataset.id); if (idx < 0 || el.dataset.id === src) return load();
    const srcPath = (pageById(src) || S.folders.find(f => f.id === src) || {}).path || ',';
    if (srcPath === path) act('within', { id: src, idx }); else { if (path.includes(',' + src + ',')) return load(); act('between', { id: src, path, idx }); } });
  main.addEventListener('dragend', () => { clr(); dragId = ''; setTimeout(load, 300); });

  load(); setInterval(load, 3000);
})();
