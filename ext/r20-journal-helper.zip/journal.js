// Roll20 저널 도우미 - 저널 사이트에서 도는 부분
// 1) 저널이 보낸 !상점반영 명령을 배경 스크립트로 전달
// 2) 이 브라우저의 저널 로그인 표(기기 토큰)를 배경 스크립트에 알려 줘요 → 확장이 같은 권한으로 실시간 서버(판매 요청·상점 입장)를 읽어요
//    (2차 보안 수정 뒤로는 로그인한 기기만 실시간 서버를 읽을 수 있어요. GM으로 로그인한 저널을 한 번 열어 두면 돼요)
(function () {
  window.addEventListener('message', e => {
    if (e.source !== window) return; const d = e.data;
    if (!d || d.src !== 'r20jh-journal' || typeof d.cmd !== 'string' || !/^!상점반영 /.test(d.cmd)) return;
    try { chrome.runtime.sendMessage({ type: 'journalCmd', cmd: d.cmd.slice(0, 20000), url: location.origin + location.pathname }); } catch (x) {}
  });
  const PFX = { '/Phandelverdelver/': 'pandelver:', '/TUEdragonheist/': 'weekday:', '/Dragonheisthesit/': 'dragonheist:' };
  let last = '';
  function sendTk() {
    try {
      const base = Object.keys(PFX).find(p => location.pathname.indexOf(p) === 0);
      const pf = base ? PFX[base] : '';
      const tk = localStorage.getItem(pf + 'adv_dev_tk') || localStorage.getItem('adv_dev_tk') || '';
      if (!tk || tk === last) return; last = tk;
      chrome.runtime.sendMessage({ type: 'devtk', url: location.origin + location.pathname, tk: tk });
    } catch (x) {}
  }
  sendTk(); setInterval(sendTk, 30000);
  // 자동 반영이 켜져 있으면 저널에 표시 → 저널이 R20(복사) 버튼을 숨겨요 (확장 없는 PC에서는 그대로 보여요)
  function mark(on) { try { if (on) document.documentElement.setAttribute('data-r20jh-auto', '1'); else document.documentElement.removeAttribute('data-r20jh-auto'); } catch (x) {} }
  try { chrome.storage.sync.get('auto', s => mark(!!(s && s.auto))); chrome.storage.onChanged.addListener((ch, area) => { if (area === 'sync' && ch.auto) mark(!!ch.auto.newValue); }); } catch (x) {}
  // 3) 확장 → 저널 페이지: 가방 반영 / 세션 로그 (페이지가 GM 로그인 상태일 때 처리해요)
  try { chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'bag' && m.data) window.postMessage({ src: 'r20jh-ext', type: 'bag', data: m.data }, location.origin); }); } catch (x) {}
  if (/^#r20log/.test(location.hash)) {
    try { history.replaceState(null, '', location.pathname + location.search); } catch (x) {}
    try { chrome.runtime.sendMessage({ type: 'getLog', url: location.origin + location.pathname }, r => {
      if (chrome.runtime.lastError || !r || !r.ok || !r.log) return;
      window.postMessage({ src: 'r20jh-ext', type: 'log', html: r.log.html, date: r.log.date || '' }, location.origin);
    }); } catch (x) {}
  }
})();
