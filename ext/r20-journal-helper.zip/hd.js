// Roll20 저널 도우미 — Mod가 깐 애니메이션(상태 고리·범위 템플릿)을 선명한 원본으로 바꿔요.
//  Roll20 Mod는 업로드 파일을 작은 미리보기(thumb, 200px)로만 깔 수 있어서, GM 브라우저가 대신 원본(med)으로 바꿔 줘요.
//  GM이 같은 맵을 보고 있을 때만 바뀌어요. 한 번 바뀌면 모두에게 선명하게 보여요.
(() => {
  const RX = /^(pcmk|pctpl|tpl)\b/i;
  const tick = () => {
    try {
      if (!window.is_gm) return;
      const C = window.Campaign; if (!C || !C.activePage) return;
      const pg = C.activePage(); if (!pg || !pg.thegraphics) return;
      pg.thegraphics.models.forEach(g => {
        const n = g.get('name') || '', s = g.get('imgsrc') || '';
        if (RX.test(n) && /\/thumb\.webm/.test(s)) g.save({ imgsrc: s.replace('/thumb.webm', '/med.webm') });
      });
    } catch (e) { /* 조용히 */ }
  };
  setInterval(tick, 1500);
})();

// 0.7.1: GM이 PL 리본이 없는 맵을 보고 있으면 화면 위 가운데에 알림 띠 (맵이 커서 왼쪽 위 글씨가 안 보여도 알 수 있게)
(() => {
  let bar = null, hideFor = '';
  const mk = () => { bar = document.createElement('div'); bar.id = 'r20h-offmap';
    bar.style.cssText = 'position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:10050;background:rgba(200,80,0,.95);color:#fff;font:600 14px/1.3 "Malgun Gothic",sans-serif;padding:7px 14px 7px 16px;border-radius:999px;box-shadow:0 4px 14px rgba(0,0,0,.45);display:none;align-items:center;gap:10px;pointer-events:auto;';
    bar.innerHTML = '<span></span><button title="이 맵에서는 그만 보기" style="border:0;background:rgba(255,255,255,.25);color:#fff;border-radius:999px;width:22px;height:22px;cursor:pointer;font-weight:700">✕</button>';
    bar.querySelector('button').onclick = () => { hideFor = bar.dataset.pg || ''; bar.style.display = 'none'; };
    document.body.appendChild(bar); };
  const tick = () => {
    try {
      if (!window.is_gm) return;
      const C = window.Campaign; if (!C || !C.activePage || !C.pages) return;
      const pg = C.activePage(); if (!pg) return;
      const cur = pg.id, pl = C.get('playerpageid'), sp = C.get('playerspecificpages') || {};
      const here = cur === pl || Object.values(sp).includes(cur);
      if (!bar) mk();
      if (here || hideFor === cur) { bar.style.display = 'none'; if (here) hideFor = ''; return; }
      const nm = id => { const p = C.pages.get(id); return p ? (p.get('name') || '이름 없는 맵') : '?'; };
      const split = [...new Set(Object.values(sp).filter(Boolean))].filter(id => id !== pl).map(nm);
      bar.dataset.pg = cur;
      bar.querySelector('span').textContent = '⚠ 지금 보는 맵이 아니에요 · PL 리본: ' + nm(pl) + (split.length ? ' (따로: ' + split.join(', ') + ')' : '');
      bar.style.display = 'flex';
    } catch (e) { /* 조용히 */ }
  };
  setInterval(tick, 1000);
})();

// 0.7.2: 자로 범위 깔기 — 플레이어가 자(측정)를 놓으면 GM 브라우저가 Mod에 알려줘요 ('ParchmentCards 자 연결' 캐릭터의 ruler 속성)
//  플레이어는 아무것도 안 깔아도 돼요. Roll20이 다른 사람의 자를 GM 화면에도 보내 주는 걸 이용해요.
(() => {
  const BR = 'ParchmentCards 자 연결';
  let ch = null, fetched = 0, hooked = false;
  const write = (d, tries) => {
    try {
      const C = window.Campaign; if (!C || !C.characters) return;
      if (!ch || !C.characters.get(ch.id)) { ch = C.characters.models.find(c => c.get('name') === BR) || null; fetched = 0; }
      if (!ch) return;
      if (!fetched) { fetched = 1; try { ch.attribs.fetch(ch.attribs); } catch (e) {} if ((tries || 0) < 3) return setTimeout(() => write(d, (tries || 0) + 1), 1200); }
      const val = JSON.stringify(d), at = ch.attribs.find(x => x.get('name') === 'ruler');
      if (at) at.save({ current: val }); else ch.attribs.create({ name: 'ruler', current: val });
    } catch (e) { /* 조용히 */ }
  };
  const seen = {};
  const onM = m => {
    try {
      if (!m || !m.extras || !m.extras.endMeasure || !Array.isArray(m.points) || m.points.length < 2) return;
      if (localStorage.getItem('r20h_ruler') === 'off') return;
      const a = m.points[0], b = m.points[m.points.length - 1];
      if (Math.hypot(b.x - a.x, b.y - a.y) < 20) return;   // 제자리 클릭은 무시
      const k = m.player + '|' + a.x + a.y + b.x + b.y; if (seen[k] && Date.now() - seen[k] < 3000) return; seen[k] = Date.now();
      const ft = m.distances && m.distances[0] ? m.distances[0].scaleDistance : 0;
      write({ p: m.player, pg: m.page, s: m.shape, an: m.extras.angle || 0, x1: a.x, y1: a.y, x2: b.x, y2: b.y, ft, t: Date.now() });
    } catch (e) { /* 조용히 */ }
  };
  const hook = () => {
    try {
      if (hooked || !window.is_gm) return;
      const M = window.Campaign && window.Campaign.engine && window.Campaign.engine.measureManager; if (!M) return;
      const P = Object.getPrototypeOf(M);
      ['updateRemoteShape', 'broadcastMeasurement'].forEach(n => { const o = P[n]; if (typeof o !== 'function' || o.__r20h) return;
        const w = function (...args) { try { onM(args[0]); } catch (e) {} return o.apply(this, args); }; w.__r20h = 1; P[n] = w; });
      hooked = true;
    } catch (e) { /* 조용히 */ }
  };
  setInterval(hook, 2000);
})();

// 0.7.2: 맵 목록 (FVTT처럼) — GM 패널의 [맵 목록] 버튼이나 Alt+M
//  큰 썸네일 한 줄 + 가운데 제목 · 폴더·검색 · PL 리본/보는 중 표시 · 누르면 그 맵으로 · [리본 ⇨] = 플레이어를 이 맵으로
//  끌어다 놓기 = 순서 바꾸기 (폴더 머리에 놓으면 그 폴더로) · 톱니 = 폴더 옮기기·이름·보관 · [+ 폴더] = 새 폴더
(() => {
  let box = null, q = '', showArch = false, armed = '', gearOpen = '', renaming = '', dragId = '';
  const open = JSON.parse(localStorage.getItem('r20h_mapfold') || '{}');
  const saveFold = () => { try { localStorage.setItem('r20h_mapfold', JSON.stringify(open)); } catch (e) {} };
  const GEAR = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.4 7.4 0 0 0-1.7-1L15 3.3h-4l-.4 2.6a7.4 7.4 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.6 7.6 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1a7.4 7.4 0 0 0 1.7 1l.4 2.6h4l.4-2.6a7.4 7.4 0 0 0 1.7-1l2.5 1 2-3.5zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" transform="translate(-1 0)"/></svg>';
  const css = `#r20h-maps{position:fixed;left:64px;top:56px;width:380px;height:78vh;z-index:2147482000;display:flex;flex-direction:column;background:#26221e;color:#efe3c8;border:2px solid #b8893a;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,.55);font:13px/1.35 "Malgun Gothic",sans-serif;resize:both;overflow:hidden;min-width:260px;min-height:220px}
#r20h-maps .r2-hd{display:flex;gap:6px;align-items:center;padding:8px 8px 6px 12px;border-bottom:1px solid #4a3f33;cursor:move}
#r20h-maps .r2-hd b{font-size:15px;color:#f3d38a;flex:1}
#r20h-maps .r2-btn{border:1px solid #b8893a;background:transparent;color:#f3d38a;border-radius:6px;padding:2px 8px;font-size:12px;cursor:pointer}
#r20h-maps .r2-btn:hover{background:#b8893a;color:#1b1510}
#r20h-maps .r2-x{border:0;background:#4a3f33;color:#efe3c8;border-radius:999px;width:24px;height:24px;cursor:pointer}
#r20h-maps .r2-sub{padding:0 10px 6px;border-bottom:1px solid #4a3f33}
#r20h-maps input.r2-q{width:100%;box-sizing:border-box;margin:6px 0 0;padding:5px 8px;border-radius:6px;border:1px solid #5b4d3c;background:#1b1815;color:#efe3c8}
#r20h-maps .r2-sub label{font-size:11px;color:#b9a888;display:inline-flex;gap:4px;align-items:center;margin-top:5px;margin-right:10px}
#r20h-maps .r2-nf{display:none;gap:4px;margin-top:5px}
#r20h-maps .r2-nf.on{display:flex}
#r20h-maps .r2-nf input{flex:1;padding:3px 7px;border-radius:5px;border:1px solid #b8893a;background:#1b1815;color:#fff}
#r20h-maps .r2-bd{flex:1;overflow:auto;padding:4px 8px 10px}
#r20h-maps .r2-fd{display:flex;align-items:center;gap:6px;padding:6px 8px;margin-top:5px;border-radius:6px;background:#332c25;color:#f0d79c;font-weight:700;cursor:pointer;user-select:none;border:2px solid transparent}
#r20h-maps .r2-fd i{font-style:normal;width:12px;color:#b8893a}
#r20h-maps .r2-fd .r2-fn{flex:1}
#r20h-maps .r2-fd small{color:#9c8b6e;font-weight:400}
#r20h-maps .r2-fd.drop{border-color:#f3d38a;background:#4a3d2c}
#r20h-maps .r2-in{margin-left:10px;border-left:1px dashed #5b4d3c;padding-left:6px}
#r20h-maps .r2-pg{position:relative;margin-top:6px;height:86px;border-radius:8px;cursor:pointer;overflow:hidden;border:2px solid #3a322a;background:#14110f center/cover no-repeat}
#r20h-maps .r2-pg:hover{border-color:#b8893a}
#r20h-maps .r2-pg.cur{border-color:#5d8fd0}
#r20h-maps .r2-pg.drag{opacity:.4}
#r20h-maps .r2-pg.drop{box-shadow:0 -4px 0 0 #f3d38a}
#r20h-maps .r2-pg.gear{height:118px}
#r20h-maps .r2-pg::after{content:"";position:absolute;inset:0;background:linear-gradient(rgba(0,0,0,.15),rgba(0,0,0,.45))}
#r20h-maps .r2-nm{position:absolute;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;text-align:center;padding:0 44px;font-size:15px;font-weight:700;color:#fff;text-shadow:0 1px 3px #000,0 0 8px #000;pointer-events:none}
#r20h-maps .r2-pg.gear .r2-nm{bottom:32px}
#r20h-maps .r2-bgs{position:absolute;left:6px;top:5px;z-index:2;display:flex;gap:4px;pointer-events:none}
#r20h-maps .r2-bg{font-size:10px;padding:1px 7px;border-radius:999px;font-weight:700;white-space:nowrap}
#r20h-maps .r2-bg.pl{background:#b8893a;color:#1b1510}
#r20h-maps .r2-bg.sp{background:#7a5aa8;color:#fff}
#r20h-maps .r2-bg.me{background:#5d8fd0;color:#fff}
#r20h-maps .r2-bg.ar{background:#555;color:#ddd}
#r20h-maps .r2-tr{position:absolute;right:5px;top:5px;z-index:2;display:flex;gap:4px;align-items:center}
#r20h-maps .r2-rb,#r20h-maps .r2-gr{border:1px solid #f3d38a;background:rgba(27,21,16,.8);color:#f3d38a;border-radius:6px;font-size:11px;cursor:pointer;visibility:hidden}
#r20h-maps .r2-rb{padding:2px 8px}
#r20h-maps .r2-gr{width:22px;height:22px;padding:0;display:flex;align-items:center;justify-content:center}
#r20h-maps .r2-pg:hover .r2-rb,#r20h-maps .r2-pg:hover .r2-gr,#r20h-maps .r2-rb.arm,#r20h-maps .r2-gr.on{visibility:visible}
#r20h-maps .r2-rb.arm,#r20h-maps .r2-gr.on,#r20h-maps .r2-rb:hover,#r20h-maps .r2-gr:hover{background:#b8893a;color:#1b1510}
#r20h-maps .r2-ed{position:absolute;left:0;right:0;bottom:0;z-index:2;display:flex;gap:4px;align-items:center;padding:4px 6px;background:rgba(20,17,15,.9)}
#r20h-maps .r2-ed button,#r20h-maps .r2-ed select{font-size:11px;border:1px solid #6b5a43;background:#26221e;color:#efe3c8;border-radius:4px;padding:1px 6px;cursor:pointer;max-width:170px}
#r20h-maps .r2-ed input{flex:1;min-width:0;font-size:12px;padding:2px 6px;border-radius:4px;border:1px solid #b8893a;background:#1b1815;color:#fff}
#r20h-maps .r2-ok{padding:6px 10px;font-size:12px;color:#b9e3a1;border-top:1px solid #4a3f33;display:none}`;
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const fv = (f, k) => (f && typeof f.get === 'function' && f.get(k) !== undefined) ? f.get(k) : (f && f.attributes && f.attributes[k] !== undefined ? f.attributes[k] : f && f[k]);
  const note = t => { if (!box) return; const o = box.querySelector('.r2-ok'); o.textContent = t; o.style.display = 'block'; clearTimeout(note.t); note.t = setTimeout(() => { o.style.display = 'none'; }, 2500); };
  const C = () => window.Campaign;
  const PF = () => C().pageFolders;
  const folders = () => { try { return (PF() && PF().getAllFolders && PF().getAllFolders()) || []; } catch (e) { return []; } };
  const folderOpts = () => { const fs = folders(), byId = {}; fs.forEach(f => { byId[fv(f, 'id')] = f; });
    const label = f => String(fv(f, 'path') || ',').split(',').filter(Boolean).map(i => byId[i] ? fv(byId[i], 'name') : '?').concat([fv(f, 'name')]).join(' / ');
    return fs.map(f => ({ path: String(fv(f, 'path') || ',') + fv(f, 'id') + ',', name: label(f) })).sort((a, b) => a.name.localeCompare(b.name)); };
  const siblings = path => { const pages = C().pages.models.filter(p => showArch || !p.get('archived')); const it = [];
    folders().filter(f => (fv(f, 'path') || ',') === path).forEach(f => it.push({ k: 'f', o: f, id: fv(f, 'id'), pl: fv(f, 'placement') || 0 }));
    pages.filter(p => (p.get('path') || ',') === path).forEach(p => it.push({ k: 'p', o: p, id: p.id, pl: p.get('placement') || 0 }));
    return it.sort((a, b) => a.pl - b.pl); };
  const itemOf = id => { const c = C(); return c.pages.get(id) || (PF().getItemById && PF().getItemById(id)) || folders().find(f => fv(f, 'id') === id); };
  const build = () => {
    const c = C(); if (!c || !c.pages) return '';
    const cur = c.activePage && c.activePage() ? c.activePage().id : '', pl = c.get('playerpageid'), sp = c.get('playerspecificpages') || {};
    const spIds = new Set(Object.values(sp || {}).filter(Boolean));
    const pages = c.pages.models.filter(p => showArch || !p.get('archived'));
    const ql = q.trim().toLowerCase();
    const row = p => {
      const th = String(p.get('thumbnail') || '').replace('https://s3.amazonaws.com/files.d20.io/', 'https://files.d20.io/'), thMed = th.replace(/\/thumb\.(png|jpg|jpeg|webp|gif)/i, '/med.$1'), path = p.get('path') || ',';
      const b = (p.id === pl ? '<span class="r2-bg pl">PL 리본</span>' : '') + (spIds.has(p.id) ? '<span class="r2-bg sp">따로 간 PL</span>' : '') + (p.id === cur ? '<span class="r2-bg me">보는 중</span>' : '') + (p.get('archived') ? '<span class="r2-bg ar">보관</span>' : '');
      const g = gearOpen === p.id;
      const ed = !g ? '' : renaming === p.id
        ? `<div class="r2-ed" data-stop="1"><input data-rn="${esc(p.id)}" value="${esc(p.get('name') || '')}"><button data-rnok="${esc(p.id)}">저장</button><button data-rnx="1">취소</button></div>`
        : `<div class="r2-ed" data-stop="1"><select data-mv="${esc(p.id)}" title="폴더 옮기기"><option value="">폴더 옮기기…</option>${path !== ',' ? '<option value=",">(폴더 밖으로)</option>' : ''}${folderOpts().filter(f => f.path !== path).map(f => `<option value="${esc(f.path)}">${esc(f.name)}</option>`).join('')}</select>` +
          `<button data-ren="${esc(p.id)}">이름 바꾸기</button><button data-ar="${esc(p.id)}">${p.get('archived') ? '꺼내기' : '보관'}</button></div>`;
      return `<div class="r2-pg${p.id === cur ? ' cur' : ''}${g ? ' gear' : ''}" draggable="true" data-id="${esc(p.id)}" data-path="${esc(path)}" title="${esc(p.get('name'))} — 누르면 이 맵으로 · 끌어서 순서 바꾸기" style="background-image:${th ? `url('${esc(thMed)}'),url('${esc(th)}')` : 'none'}">` +
        `<div class="r2-bgs">${b}</div><div class="r2-nm">${esc(p.get('name') || '이름 없는 맵')}</div><div class="r2-tr">` +
        (p.id === pl ? '' : `<button class="r2-rb${armed === p.id ? ' arm' : ''}" data-rb="${esc(p.id)}" title="플레이어(리본)를 이 맵으로 옮겨요">${armed === p.id ? '한 번 더 누르면 옮겨요' : '리본 ⇨'}</button>`) +
        `<button class="r2-gr${g ? ' on' : ''}" data-gear="${esc(p.id)}" title="맵 설정: 폴더 옮기기 · 이름 · 보관">${GEAR}</button></div>` + ed + '</div>';
    };
    if (ql) {
      const hit = pages.filter(p => String(p.get('name') || '').toLowerCase().includes(ql)).sort((a, b) => (a.get('placement') || 0) - (b.get('placement') || 0));
      return hit.map(row).join('') || '<div style="padding:10px;color:#9c8b6e">찾는 맵이 없어요</div>';
    }
    const level = path => siblings(path).map(it => {
      if (it.k === 'p') return row(it.o);
      const f = it.o, fid = it.id, sub = path + fid + ',', isOpen = !!open[fid];
      const n = pages.filter(p => String(p.get('path') || '').startsWith(sub)).length;
      const hasPl = pages.some(p => String(p.get('path') || '').startsWith(sub) && (p.id === pl || spIds.has(p.id)));
      return `<div class="r2-fd" draggable="true" data-f="${esc(fid)}" data-path="${esc(path)}" data-sub="${esc(sub)}"><i>${isOpen ? '▾' : '▸'}</i><span class="r2-fn">${esc(fv(f, 'name'))}${hasPl && !isOpen ? ' <span class="r2-bg pl">PL</span>' : ''}</span><small>${n}</small></div>` + (isOpen ? `<div class="r2-in">${level(sub)}</div>` : '');
    }).join('');
    return level(',');
  };
  const render = () => { if (!box || dragId) return; if (renaming && box.querySelector('input[data-rn]') === box.ownerDocument.activeElement) return; const bd = box.querySelector('.r2-bd'), st = bd.scrollTop; bd.innerHTML = build(); bd.scrollTop = st; };
  const dropOn = (srcId, el) => {
    try {
      const it = itemOf(srcId); if (!it || !el) return;
      if (el.dataset.sub) {   // 폴더 머리 → 그 폴더 안 맨 아래로
        if (el.dataset.f === srcId || String(el.dataset.sub).includes(',' + srcId + ',')) return;
        PF().moveBetweenFolders(it, el.dataset.sub, {}); open[el.dataset.f] = true; saveFold(); return note('폴더로 옮겼어요');
      }
      const path = el.dataset.path || ',', sib = siblings(path), idx = sib.findIndex(x => x.id === el.dataset.id); if (idx < 0 || el.dataset.id === srcId) return;
      if ((fv(it, 'path') || ',') === path) PF().moveWithinFolder(it, idx); else { if (String(path).includes(',' + srcId + ',')) return; PF().moveBetweenFolders(it, path, { beforeIndex: idx }); }
    } catch (e) { note('옮기지 못했어요'); }
  };
  let embedded = false;
  const toggle = () => { if (box && !embedded) { box.remove(); box = null; return; } mount(document.body, false); };
  // 도구 창(따로 띄운 창) 안에 넣을 때: window.__r20hMapsMount(그 창의 칸)
  window.__r20hMapsMount = host => { if (box) box.remove(); box = null; mount(host, true); };
  window.__r20hMapsUnmount = () => { if (box && embedded) { box.remove(); box = null; embedded = false; } };
  const mount = (host, emb) => {
    if (!window.is_gm) return;
    embedded = emb; const doc = host.ownerDocument;
    if (!doc.getElementById('r20h-maps-css')) { const s = doc.createElement('style'); s.id = 'r20h-maps-css'; s.textContent = css + (emb ? '\n#r20h-maps{position:static!important;width:100%!important;height:100%!important;border:0!important;border-radius:0!important;box-shadow:none!important;resize:none!important}#r20h-maps .r2-x,#r20h-maps [data-win]{display:none}' : ''); doc.head.appendChild(s); }
    box = doc.createElement('div'); box.id = 'r20h-maps';
    box.innerHTML = `<div class="r2-hd"><b>맵 목록</b><button class="r2-btn" data-nfopen="1" title="새 폴더 만들기">+ 폴더</button><button class="r2-btn" data-win="1" title="맵·개요서·그림 라이브러리를 한 창에 따로 띄워요">창으로</button><button class="r2-x" title="닫기 (Alt+M)">✕</button></div>` +
      `<div class="r2-sub"><input class="r2-q" type="search" placeholder="맵 이름 검색"><div class="r2-nf"><input data-nfname="1" placeholder="새 폴더 이름"><button class="r2-btn" data-nfok="1">만들기</button></div><label><input type="checkbox" data-arch="1"> 보관한 맵도 보기</label></div><div class="r2-bd"></div><div class="r2-ok"></div>`;
    host.appendChild(box);
    if (!emb) try { const p = JSON.parse(localStorage.getItem('r20h_mappos') || 'null'); if (p) { box.style.left = Math.max(0, Math.min(innerWidth - 120, p.x)) + 'px'; box.style.top = Math.max(0, Math.min(innerHeight - 60, p.y)) + 'px'; if (p.w) box.style.width = p.w + 'px'; if (p.h) box.style.height = p.h + 'px'; } } catch (e) {}
    box.querySelector('.r2-x').onclick = toggle;
    const savePos = () => { try { localStorage.setItem('r20h_mappos', JSON.stringify({ x: box.offsetLeft, y: box.offsetTop, w: box.offsetWidth, h: box.offsetHeight })); } catch (er) {} };
    if (!emb) new ResizeObserver(() => { if (box) savePos(); }).observe(box);
    const inp = box.querySelector('input[type=search]'); inp.value = q; inp.oninput = () => { q = inp.value; render(); }; setTimeout(() => inp.focus(), 50);
    const cb = box.querySelector('input[data-arch]'); cb.checked = showArch; cb.onchange = () => { showArch = cb.checked; render(); };
    const mkFolder = () => { const nm = box.querySelector('[data-nfname]'), v = nm.value.trim(); if (!v) return note('폴더 이름을 적어 주세요');
      try { PF().addFolder(v, ','); nm.value = ''; box.querySelector('.r2-nf').classList.remove('on'); note('새 폴더를 만들었어요 (맨 아래) · 맵을 끌어다 넣으세요'); } catch (er) { note('폴더를 못 만들었어요'); } setTimeout(render, 500); };
    box.addEventListener('keydown', e => { e.stopPropagation();
      if (e.key === 'Enter' && e.target.dataset.nfname) mkFolder();
      if (e.key === 'Enter' && e.target.dataset.rn) { const p = C().pages.get(e.target.dataset.rn); if (p && e.target.value.trim()) p.save({ name: e.target.value.trim() }); renaming = ''; setTimeout(render, 300); }
      if (e.key === 'Escape' && renaming) { renaming = ''; render(); } }, true);
    box.addEventListener('change', e => { const mv = e.target.dataset && e.target.dataset.mv; if (!mv || !e.target.value) return;
      try { PF().moveBetweenFolders(itemOf(mv), e.target.value, {}); const f = String(e.target.value).split(',').filter(Boolean).pop(); if (f) { open[f] = true; saveFold(); } gearOpen = ''; note('폴더를 옮겼어요'); } catch (er) { note('폴더를 못 옮겼어요'); }
      setTimeout(render, 500); });
    // 끌어다 놓기
    const bd = box.querySelector('.r2-bd'); let overEl = null;
    const clearOver = () => { if (overEl) overEl.classList.remove('drop'); overEl = null; };
    bd.addEventListener('dragstart', e => { const el = e.target.closest('[data-id],[data-f]'); if (!el) return; dragId = el.dataset.id || el.dataset.f; el.classList.add('drag'); try { e.dataTransfer.setData('text/plain', dragId); e.dataTransfer.effectAllowed = 'move'; } catch (er) {} });
    bd.addEventListener('dragover', e => { if (!dragId) return; const el = e.target.closest('[data-id],[data-f]'); if (!el) return; e.preventDefault(); if (el !== overEl) { clearOver(); overEl = el; el.classList.add('drop'); } });
    bd.addEventListener('dragleave', e => { if (overEl && !overEl.contains(e.relatedTarget)) clearOver(); });
    bd.addEventListener('drop', e => { e.preventDefault(); const el = e.target.closest('[data-id],[data-f]'), src = dragId; clearOver(); dragId = ''; if (src && el) dropOn(src, el); setTimeout(render, 500); });
    bd.addEventListener('dragend', () => { clearOver(); dragId = ''; setTimeout(render, 300); });
    bd.addEventListener('scroll', () => {}, { passive: true });
    box.addEventListener('click', e => {
      const c = C(), t = e.target, d = (t.closest('button,select,input') || {}).dataset || {};
      if (d.win) { if (window.__r20hTools) window.__r20hTools('maps'); return; }
      if (d.nfopen) { const nf = box.querySelector('.r2-nf'); nf.classList.toggle('on'); if (nf.classList.contains('on')) box.querySelector('[data-nfname]').focus(); return; }
      if (d.nfok) return mkFolder();
      if (d.gear) { e.stopPropagation(); gearOpen = gearOpen === d.gear ? '' : d.gear; renaming = ''; return render(); }
      if (d.ren) { e.stopPropagation(); renaming = d.ren; render(); const i = box.querySelector('input[data-rn]'); if (i) { i.focus(); i.select(); } return; }
      if (d.rnok) { e.stopPropagation(); const i = box.querySelector('input[data-rn]'), p = c.pages.get(d.rnok); if (p && i && i.value.trim()) p.save({ name: i.value.trim() }); renaming = ''; return setTimeout(render, 300); }
      if (d.rnx) { e.stopPropagation(); renaming = ''; return render(); }
      if (d.ar) { e.stopPropagation(); const p = c.pages.get(d.ar); if (p) { const now = !p.get('archived'); p.save({ archived: now }); gearOpen = ''; note(now ? '보관했어요 (위의 "보관한 맵도 보기"로 다시 볼 수 있어요)' : '꺼냈어요'); } return setTimeout(render, 400); }
      if (d.rb) { e.stopPropagation(); const p = c.pages.get(d.rb); if (!p) return;
        if (armed !== d.rb) { armed = d.rb; render(); clearTimeout(toggle.at); toggle.at = setTimeout(() => { armed = ''; render(); }, 4000); return; }
        armed = ''; try { c.save({ playerpageid: d.rb, playerspecificpages: false }); note('플레이어를 ' + p.get('name') + ' 맵으로 옮겼어요'); } catch (er) { note('리본을 못 옮겼어요'); }
        return setTimeout(render, 600); }
      if (t.closest('[data-stop]') || t.closest('select,input')) return;
      const fd = t.closest('[data-f]'); if (fd) { open[fd.dataset.f] = !open[fd.dataset.f]; saveFold(); return render(); }
      const pg = t.closest('[data-id]'); if (pg) { try { c.switchPageById(pg.dataset.id); } catch (er) { note('맵을 못 열었어요'); } setTimeout(render, 600); }
    });
    const hd = box.querySelector('.r2-hd'); hd.onmousedown = e => { if (emb || e.target.closest('button')) return; const sx = e.clientX - box.offsetLeft, sy = e.clientY - box.offsetTop;
      const mv = ev => { box.style.left = (ev.clientX - sx) + 'px'; box.style.top = (ev.clientY - sy) + 'px'; };
      const up = () => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); savePos(); };
      addEventListener('mousemove', mv); addEventListener('mouseup', up); };
    try { const c = C(); [c.activePage && c.activePage() && c.activePage().id, c.get('playerpageid')].forEach(id => { const p = id && c.pages.get(id); if (!p) return; String(p.get('path') || '').split(',').filter(Boolean).forEach(f => { open[f] = true; }); }); } catch (e) {}
    render();
  };
  setInterval(() => { if (box && !renaming && !dragId) render(); }, 3000);
  window.addEventListener('keydown', e => { if (e.altKey && !e.ctrlKey && (e.key === 'm' || e.key === 'M' || e.code === 'KeyM')) { e.preventDefault(); toggle(); } }, true);
  window.addEventListener('message', e => { if (e.source === window && e.data && e.data.r20h === 'maps') toggle(); });
})();

// 0.7.3: 맵·장면 창(따로 띄운 창)과 그림 라이브러리·개요서 떼어내기
//  따로 창 ↔ 배경 ↔ content.js ↔ 여기(MAIN)로 {r20h:'req'} 메시지를 주고받아요
(() => {
  const fv = (f, k) => (f && typeof f.get === 'function' && f.get(k) !== undefined) ? f.get(k) : (f && f.attributes && f.attributes[k] !== undefined ? f.attributes[k] : f && f[k]);
  const C = () => window.Campaign, PF = () => C().pageFolders;
  const BR = 'ParchmentCards 자 연결'; let ch = null, fetched = false;
  const bridgeAttr = name => { try { const c = C(); if (!ch || !c.characters.get(ch.id)) { ch = c.characters.models.find(x => x.get('name') === BR) || null; fetched = false; }
      if (!ch) return null; if (!fetched) { fetched = true; try { ch.attribs.fetch(ch.attribs); } catch (e) {} } const a = ch.attribs.find(x => x.get('name') === name); return a ? a.get('current') : null; } catch (e) { return null; } };
  const thumb = p => String(p.get('thumbnail') || '').replace('https://s3.amazonaws.com/files.d20.io/', 'https://files.d20.io/');
  const itemOf = id => { const c = C(); return c.pages.get(id) || (PF().getItemById && PF().getItemById(id)) || (PF().getAllFolders() || []).find(f => fv(f, 'id') === id); };
  const ops = {
    state: () => { const c = C(); let jb = [], sc = null; try { jb = JSON.parse(c.get('jukeboxfolder') || '[]').filter(x => x && typeof x === 'object' && x.id).map(x => ({ id: x.id, n: x.n })); } catch (e) {}
      try { sc = JSON.parse(bridgeAttr('scenes') || 'null'); } catch (e) {}
      const sp = c.get('playerspecificpages') || {};
      return { gm: !!window.is_gm, game: document.title.replace(/\s*\|\s*Roll20.*$/, ''), cur: c.activePage && c.activePage() ? c.activePage().id : '', pl: c.get('playerpageid'), sp: Object.values(sp || {}).filter(Boolean),
        pages: c.pages.models.map(p => ({ id: p.id, name: p.get('name') || '', thumb: thumb(p), path: p.get('path') || ',', pl: p.get('placement') || 0, ar: !!p.get('archived') })),
        folders: (PF().getAllFolders() || []).map(f => ({ id: fv(f, 'id'), name: fv(f, 'name'), path: fv(f, 'path') || ',', pl: fv(f, 'placement') || 0 })), jb, scenes: sc }; },
    go: a => { C().switchPageById(a.id); return true; },
    ribbon: a => { C().save({ playerpageid: a.id, playerspecificpages: false }); return true; },
    within: a => { PF().moveWithinFolder(itemOf(a.id), a.idx); return true; },
    between: a => { PF().moveBetweenFolders(itemOf(a.id), a.path, a.idx >= 0 ? { beforeIndex: a.idx } : {}); return true; },
    rename: a => { const p = C().pages.get(a.id); if (p) p.save({ name: a.name }); return !!p; },
    archive: a => { const p = C().pages.get(a.id); if (p) p.save({ archived: !!a.on }); return !!p; },
    addFolder: a => { PF().addFolder(a.name, a.path || ','); return true; },
    float: a => { floatPanel(a.which); return true; }
  };
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.r20h !== 'req') return;
    let data = null, error = null;
    try { if (!window.is_gm) throw new Error('GM으로 들어온 게임 화면이 아니에요'); const f = ops[e.data.op]; if (!f) throw new Error('모르는 요청'); data = f(e.data.args || {}); } catch (er) { error = String(er && er.message || er); }
    window.postMessage({ r20h: 'res', id: e.data.id, data, error }, '*');
  });

  // ---- 그림 라이브러리·개요서를 채팅과 따로 (게임 화면 안의 떠 있는 창으로) ----
  const PANELS = { art: { id: 'imagedialog', tab: 'arttab', name: '그림 라이브러리' }, comp: { id: 'vm_compendium_panel', tab: 'vm_compendiumtab', name: '개요서' }, journal: { id: 'journal', tab: 'journaltab', name: '저널' }, jukebox: { id: 'jukebox', tab: 'jukeboxtab', name: '주크박스' } };
  const floats = {};
  const fcss = `.r20h-float{position:fixed;z-index:2147481000;display:flex;flex-direction:column;background:#fff;border:2px solid #b8893a;border-radius:8px;box-shadow:0 8px 28px rgba(0,0,0,.5);resize:both;overflow:hidden;min-width:260px;min-height:200px}
.r20h-float .r20h-fh{display:flex;align-items:center;gap:6px;padding:5px 6px 5px 10px;background:#26221e;color:#f3d38a;font:700 13px "Malgun Gothic",sans-serif;cursor:move;flex:none}
.r20h-float .r20h-fh span{flex:1}
.r20h-float .r20h-fh button{border:1px solid #b8893a;background:transparent;color:#f3d38a;border-radius:5px;font-size:11px;padding:1px 7px;cursor:pointer}
.r20h-float .r20h-fb{flex:1;overflow:auto;position:relative}
.r20h-float .r20h-fb > .ui-tabs-panel{display:block !important;height:100% !important;width:auto !important;position:static !important;overflow:auto}`;
  const floatPanel = which => {
    const P = PANELS[which]; if (!P) return;
    if (twHome[which]) { openTools(which); return; }
    if (floats[which]) return dock(which);
    const el = document.getElementById(P.id); if (!el) return;
    if (!document.getElementById('r20h-float-css')) { const s = document.createElement('style'); s.id = 'r20h-float-css'; s.textContent = fcss; document.head.appendChild(s); }
    const w = document.createElement('div'); w.className = 'r20h-float';
    let pos = null; try { pos = JSON.parse(localStorage.getItem('r20h_float_' + which) || 'null'); } catch (e) {}
    pos = pos || { x: Math.max(60, innerWidth - 760), y: 60, w: 380, h: Math.round(innerHeight * 0.75) };
    Object.assign(w.style, { left: Math.max(0, Math.min(innerWidth - 120, pos.x)) + 'px', top: Math.max(0, Math.min(innerHeight - 60, pos.y)) + 'px', width: pos.w + 'px', height: pos.h + 'px' });
    w.innerHTML = `<div class="r20h-fh"><span>${P.name}</span><button data-dock="1" title="원래 자리(오른쪽 탭)로 돌려놓기">탭으로 돌려놓기</button></div><div class="r20h-fb"></div>`;
    document.body.appendChild(w);
    const home = { parent: el.parentNode, next: el.nextSibling };
    w.querySelector('.r20h-fb').appendChild(el);
    el.style.display = 'block';
    const tabLi = document.querySelector(`#rightsidebar a[href="#${P.id}"]`); const li = tabLi && tabLi.closest('li'); if (li) li.style.display = 'none';
    // 지금 그 탭이 열려 있었으면 채팅으로 돌아가요
    try { const chat = document.querySelector('#rightsidebar a[href="#textchat"]'); if (chat) chat.click(); } catch (e) {}
    const save = () => { try { localStorage.setItem('r20h_float_' + which, JSON.stringify({ x: w.offsetLeft, y: w.offsetTop, w: w.offsetWidth, h: w.offsetHeight })); } catch (e) {} };
    new ResizeObserver(save).observe(w);
    w.querySelector('[data-dock]').onclick = () => dock(which);
    w.querySelector('.r20h-fh').onmousedown = e => { if (e.target.closest('button')) return; const sx = e.clientX - w.offsetLeft, sy = e.clientY - w.offsetTop;
      const mv = ev => { w.style.left = (ev.clientX - sx) + 'px'; w.style.top = (ev.clientY - sy) + 'px'; }; const up = () => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); save(); };
      addEventListener('mousemove', mv); addEventListener('mouseup', up); };
    floats[which] = { w, el, home, li };
    try { localStorage.setItem('r20h_floaton_' + which, '1'); } catch (e) {}
  };
  const dock = which => {
    const f = floats[which]; if (!f) return;
    try { if (f.home.next && f.home.next.parentNode === f.home.parent) f.home.parent.insertBefore(f.el, f.home.next); else f.home.parent.appendChild(f.el); } catch (e) {}
    f.el.style.display = 'none'; if (f.li) f.li.style.display = ''; f.w.remove(); delete floats[which];
    try { localStorage.removeItem('r20h_floaton_' + which); } catch (e) {}
  };
  // ---- 도구 창: 맵 · 개요서 · 그림 라이브러리를 한 창에 (브라우저 창을 따로 띄워요) ----
  let tw = null, twHome = {};
  const twCss = `body{margin:0;background:#1d1a17;color:#efe3c8;font:13px/1.4 "Malgun Gothic",sans-serif;height:100vh;display:flex;flex-direction:column;overflow:hidden}
#r20h-tb{display:flex;gap:6px;align-items:center;padding:8px 10px;background:#26221e;border-bottom:2px solid #b8893a;flex:none}
#r20h-tb b{color:#f3d38a;margin-right:10px;font-size:15px}
#r20h-tb button{border:1px solid #6b5a43;background:transparent;color:#efe3c8;border-radius:999px;padding:4px 14px;cursor:pointer;font-size:13px}
#r20h-tb button.on{background:#b8893a;border-color:#b8893a;color:#1b1510;font-weight:700}
#r20h-tb .hint{margin-left:auto;font-size:11px;color:#9c8b6e}
.r20h-pane{flex:1;overflow:auto;display:none;background:#fff;color:#222}
.r20h-pane.on{display:block}
#r20h-pane-maps{background:#26221e}
.r20h-pane > .ui-tabs-panel{display:block!important;height:100%!important;width:auto!important;position:static!important;overflow:auto}`;
  const twShow = (which) => { if (!tw || tw.closed) return; const d = tw.document;
    d.querySelectorAll('#r20h-tb button').forEach(b => b.classList.toggle('on', b.dataset.t === which));
    d.querySelectorAll('.r20h-pane').forEach(p => p.classList.toggle('on', p.id === 'r20h-pane-' + which)); try { localStorage.setItem('r20h_toolsTab', which); } catch (e) {} };
  const twGive = (which) => {   // 오른쪽 탭의 패널을 도구 창으로 옮겨요
    const P = PANELS[which]; if (!P || twHome[which]) return; if (floats[which]) dock(which);
    const el = document.getElementById(P.id); if (!el) return;
    twHome[which] = { el, parent: el.parentNode, next: el.nextSibling };
    tw.document.getElementById('r20h-pane-' + which).appendChild(el); el.style.display = 'block';
    const a = document.querySelector(`#rightsidebar a[href="#${P.id}"]`), li = a && a.closest('li'); if (li) { li.style.display = 'none'; twHome[which].li = li; }
  };
  const twBack = () => { Object.keys(twHome).forEach(k => { const h = twHome[k]; try { if (h.next && h.next.parentNode === h.parent) h.parent.insertBefore(h.el, h.next); else h.parent.appendChild(h.el); } catch (e) {} h.el.style.display = 'none'; if (h.li) h.li.style.display = ''; });
    twHome = {}; try { if (window.__r20hMapsUnmount) window.__r20hMapsUnmount(); } catch (e) {} };
  let twAsk = null;
  const openTools = (which) => {
    which = which || localStorage.getItem('r20h_toolsTab') || 'maps';
    if (tw && !tw.closed) { twShow(which); tw.focus(); return; }
    tw = window.open('', 'r20h_tools', 'popup=yes,width=1000,height=820');
    if (!tw) {   // 팝업이 막혔으면 화면에 누를 버튼을 띄워요 (누르면 열려요)
      if (twAsk) twAsk.remove();
      twAsk = document.createElement('button'); twAsk.textContent = '도구 창 열기 (맵 · 개요서 · 그림 라이브러리)';
      twAsk.style.cssText = 'position:fixed;top:54px;left:50%;transform:translateX(-50%);z-index:2147483000;background:#b8893a;color:#1b1510;border:0;border-radius:999px;padding:9px 18px;font:700 14px "Malgun Gothic",sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.45);cursor:pointer';
      twAsk.onclick = () => { twAsk.remove(); twAsk = null; openTools(which); }; document.body.appendChild(twAsk); setTimeout(() => { if (twAsk) { twAsk.remove(); twAsk = null; } }, 15000); return;
    }
    const d = tw.document;
    d.open(); d.write('<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><title>도구 — 맵 · 개요서 · 그림 라이브러리</title></head><body></body></html>'); d.close();
    document.querySelectorAll('link[rel="stylesheet"], style').forEach(n => { if (/r20h-(maps|float)-css/.test(n.id || '')) return; try { d.head.appendChild(d.importNode(n, true)); } catch (e) {} });
    const st = d.createElement('style'); st.textContent = twCss; d.head.appendChild(st);
    d.body.innerHTML = `<div id="r20h-tb"><b>도구</b><button data-t="maps">맵</button><button data-t="comp">개요서</button><button data-t="art">그림 라이브러리</button><span class="hint">이 창을 닫으면 개요서·그림 라이브러리는 오른쪽 탭으로 돌아가요</span></div>` +
      '<div class="r20h-pane" id="r20h-pane-maps"></div><div class="r20h-pane" id="r20h-pane-comp"></div><div class="r20h-pane" id="r20h-pane-art"></div>';
    d.getElementById('r20h-tb').addEventListener('click', e => { const b = e.target.closest('button[data-t]'); if (b) twShow(b.dataset.t); });
    try { if (window.__r20hMapsMount) window.__r20hMapsMount(d.getElementById('r20h-pane-maps')); } catch (e) {}
    twGive('comp'); twGive('art');
    try { const chat = document.querySelector('#rightsidebar a[href="#textchat"]'); if (chat) chat.click(); } catch (e) {}
    twShow(which);
    const watch = setInterval(() => { if (!tw || tw.closed) { clearInterval(watch); twBack(); tw = null; } }, 800);
    tw.addEventListener('pagehide', () => { setTimeout(() => { if (!tw || tw.closed) { twBack(); tw = null; } }, 300); });
  };
  window.__r20hTools = openTools;
  window.addEventListener('keydown', e => { if (e.altKey && !e.ctrlKey && e.code === 'KeyT') { e.preventDefault(); openTools(); } }, true);
  window.addEventListener('beforeunload', () => { try { if (tw && !tw.closed) tw.close(); } catch (e) {} });
  window.addEventListener('message', e => { if (e.source === window && e.data && e.data.r20h === 'tools') openTools(e.data.which); });
  // 새로 고쳐도 떼어 둔 창은 다시 떼어 둬요
  setTimeout(() => { Object.keys(PANELS).forEach(k => { if (localStorage.getItem('r20h_floaton_' + k) === '1' && window.is_gm && !floats[k]) floatPanel(k); }); }, 8000);
  window.addEventListener('keydown', e => { if (!e.altKey || e.ctrlKey) return; if (e.code === 'KeyK') { e.preventDefault(); floatPanel('comp'); } if (e.code === 'KeyL') { e.preventDefault(); floatPanel('art'); } }, true);
  window.addEventListener('message', e => { if (e.source === window && e.data && e.data.r20h === 'float') floatPanel(e.data.which); });
})();

// 0.7.6: PC 시트 → 저널 — 레벨이 바뀐 PC를 알려 주고, 내보낼 때 시트를 모아 줘요 (시트 창을 열지 않고 읽어요)
(() => {
  const C = () => window.Campaign;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let base = null, known = new Set(), skip = new Set(), hooked = {}, notifyT = null, lastKey = null;
  const lvOf = p => {
    if (p.store) {
      const I = Object.values(((p.store.integrants || {}).integrants) || {}).filter(v => v.type === 'Class Level' && v._enabled !== false);
      const by = {}; let tot = 0;
      I.forEach(v => { if (v.name) by[v.name] = Math.max(by[v.name] || 0, +v.level || 0); tot = Math.max(tot, +v.totalLevel || 0); });
      return Math.max(tot, Object.values(by).reduce((a, x) => a + x, 0));
    }
    const a = p.attrs || {}; return +((a.level || a.base_level || [0])[0]) || 0;
  };
  const pcs = () => C().characters.models.filter(c => c.get('controlledby') && (known.has(c.id) || (!skip.has(c.id) && !c.get('archived'))));
  async function ensure(c) {
    if (!c.__sxF) { c.__sxF = 1; try { c.attribs.fetch(c.attribs); } catch (e) {} }
    for (let i = 0; i < 24 && !c.attribs.length; i++) await sleep(250);
    for (let i = 0, n = -1, same = 0; i < 24 && same < 3; i++) { if (c.attribs.length === n) same++; else same = 0; n = c.attribs.length; if (same < 3) await sleep(250); }
  }
  function snap(c) {
    const A = {}; c.attribs.each(a => { A[a.get('name')] = a; });
    const p = { id: c.id, name: c.get('name'), avatar: c.get('avatar'), sheet: c.get('charactersheetname') };
    if (A.store) { let s = A.store.get('current'); if (typeof s === 'string') { try { s = JSON.parse(s); } catch (e) {} } p.store = s; if (A.sheetVersion) p.sheetVersion = A.sheetVersion.get('current'); }
    else { p.attrs = {}; Object.keys(A).forEach(k => { p.attrs[k] = [A[k].get('current'), A[k].get('max')]; }); }
    return p;
  }
  function diff() {
    if (!base) return;
    const out = [];
    pcs().forEach(c => { if (!c.attribs.length) return; const p = snap(c); if (!p.store && !Object.keys(p.attrs).length) return; const now = lvOf(p), was = base[c.id];
      if (was == null) out.push({ n: p.name, to: now, isNew: 1 }); else if (was && was !== now) out.push({ n: p.name, from: was, to: now }); });
    const key = JSON.stringify(out);
    if (key === lastKey) return; lastKey = key;
    window.postMessage({ r20h: 'sxLvl', list: out }, '*');
  }
  const later = ms => { clearTimeout(notifyT); notifyT = setTimeout(diff, ms); };
  // 입장 직후엔 Roll20이 바쁘니까 2분 기다렸다가, 시트를 한 명씩 5초 간격으로 천천히 읽어요 (0.7.8)
  let watching = false;
  async function watch() {
    if (watching) return; watching = true;
    await sleep(Math.max(0, 120000 - performance.now()));
    for (const c of pcs()) {
      if (!c.attribs.length) await sleep(5000);
      await ensure(c);
      if (hooked[c.id]) continue; hooked[c.id] = 1;
      // 레벨업은 여러 번에 나눠 고치니까, 마지막으로 고친 뒤 1분 지나서 알려요
      c.attribs.on('change add', a => { if (a && a.get && a.get('name') === 'store' || a && a.get && /level/i.test(a.get('name') || '')) later(60000); });
    }
    watching = false; later(500);
  }
  function sxPick(chars, names) {   // 저널에 PC로 등록한 이름 → Roll20 캐릭터 하나씩 (이름이 조금 달라도: '바를로니카야 루벡' → '바를로')
    const nm = s => String(s || '').replace(/[?*？]+/g, '').replace(/\s+/g, ' ').trim();
    const out = [];
    names.forEach(J => { const j = nm(J); if (!j) return; let best = null, bs = -1;
      chars.forEach(c => { const n = nm(c.name); if (!n) return; const exact = n === j; if (!exact && !(n.length >= 2 && (j.startsWith(n) || n.startsWith(j)))) return;
        const sc = (exact ? 100 : 0) + (c.sheet === 'dnd2024byroll20' ? 10 : 0) + (/[?*？]/.test(c.name) ? 0 : 5) + (n.length / 100); if (sc > bs) { bs = sc; best = c; } });
      if (best && !out.some(o => o.c.id === best.id)) out.push({ c: best, j: J }); });
    return out;
  }
  async function collect(names) {
    const out = [];
    // 저널에 PC로 등록한 캐릭터만 (목록을 못 받았으면 예전처럼 플레이어가 조종하는 캐릭터 전부)
    let list = pcs().map(c => ({ c, j: '' }));
    if (Array.isArray(names) && names.length) list = sxPick(C().characters.models.filter(c => !c.get('archived') && c.get('controlledby')).map(c => ({ id: c.id, name: c.get('name'), sheet: c.get('charactersheetname'), m: c })), names).map(x => ({ c: x.c.m, j: x.j }));
    for (const { c, j } of list) { await ensure(c); const p = snap(c); if (!p.store && !Object.keys(p.attrs).length) continue; if (j) p.jname = j; out.push(p); }
    // 동행 크리처: PC와 같은 플레이어가 조종하는 다른 캐릭터 (이름에 ?·*가 붙은 예전 중복 시트, PC 이름이 들어간 사본은 빼요)
    if (Array.isArray(names) && names.length) {
      const pl = c => String(c.get('controlledby') || '').split(',').map(x => x.trim()).filter(x => x && x !== 'all');
      const owners = list.map(({ c, j }) => ({ j, ps: pl(c), n: String(c.get('name') || '') }));
      const taken = new Set(list.map(x => x.c.id));
      for (const c of C().characters.models) {
        if (taken.has(c.id) || c.get('archived')) continue;
        const nm = String(c.get('name') || ''); if (/[?*？]/.test(nm) || /^!/.test(nm)) continue;
        if (owners.some(o => o.n && (nm.includes(o.n) || o.n.includes(nm)))) continue;
        const ps = pl(c); if (!ps.length) continue;
        const o = owners.find(o => o.ps.some(x => ps.includes(x))); if (!o) continue;
        await ensure(c); const p = snap(c); if (!p.store) continue;   // 2024 시트만
        p.comp = o.j; out.push(p);
      }
    }
    return { cid: window.campaign_id, pcs: out };
  }
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data) return;
    if (e.data.r20h === 'sxInit' && window.is_gm) { base = e.data.base || {}; known = new Set(Object.keys(base)); skip = new Set(e.data.skip || []); lastKey = null; watch(); }
    if (e.data.r20h === 'sxReq') {
      const id = e.data.id;
      (async () => { if (!window.is_gm) throw new Error('GM으로 들어온 게임 화면이 아니에요'); return collect(e.data.names); })()
        .then(data => window.postMessage({ r20h: 'res', id, data }, '*'), er => window.postMessage({ r20h: 'res', id, error: String(er && er.message || er) }, '*'));
    }
  });
})();
